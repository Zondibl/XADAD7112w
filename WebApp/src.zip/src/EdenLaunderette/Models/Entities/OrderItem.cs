namespace EdenLaunderette.Models;

public class OrderItem
{
    public int OrderItemId { get; set; }
    public int OrderId { get; set; }
    public string ItemType { get; set; } = "";
    public int Quantity { get; set; }
    public string? ConditionNotes { get; set; }
    public string? ItemNotes { get; set; }
    public DateTime CreatedAt { get; set; } = Clock.Now;

    public ICollection<OrderItemService> Services { get; set; } = new List<OrderItemService>();
}
