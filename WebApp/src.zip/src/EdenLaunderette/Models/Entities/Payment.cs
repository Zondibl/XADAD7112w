namespace EdenLaunderette.Models;

public class Payment
{
    public int PaymentId { get; set; }
    public int OrderId { get; set; }
    public string ReceiptNumber { get; set; } = "";
    public decimal Amount { get; set; }
    public string PaymentMethod { get; set; } = ""; // Cash, Card, EFT or Online
    public string PaymentStatus { get; set; } = "Paid";
    public DateTime PaymentDate { get; set; } = Clock.Now;
    public int RecordedByEmployeeId { get; set; }
    public string? Notes { get; set; }
}
