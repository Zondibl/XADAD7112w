using EdenLaunderette.Data;
using EdenLaunderette.Models;
using EdenLaunderette.Models.Api;
using EdenLaunderette.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;

namespace EdenLaunderette.Controllers.Api;

// Login and sign-up for the mobile app. Customers only: staff use the website.
[ApiController, IgnoreAntiforgeryToken, Route("api/auth")]
public class AuthApiController : ControllerBase
{
    private static readonly TimeSpan TokenLifetime = TimeSpan.FromHours(12);
    private readonly AppDbContext _db;
    private readonly AccountService _accounts;
    private readonly TwoFactorService _twoFactor;
    private readonly JwtService _jwt;
    private readonly LoginAttemptTracker _attempts;
    private readonly ILogger<AuthApiController> _log;

    public AuthApiController(AppDbContext db, AccountService accounts, TwoFactorService twoFactor, JwtService jwt,
        LoginAttemptTracker attempts, ILogger<AuthApiController> log)
    { _db = db; _accounts = accounts; _twoFactor = twoFactor; _jwt = jwt; _attempts = attempts; _log = log; }

    [HttpPost("login"), EnableRateLimiting("sensitive")]
    public async Task<IActionResult> Login(ApiLoginRequest r)
    {
        if (!_jwt.IsConfigured) return StatusCode(503, new { error = "Mobile login isn't set up yet on the server." });
        var username = r.Username.Trim();
        if (_attempts.IsLocked(username, out var remaining))
            return StatusCode(429, new { error = $"Too many wrong passwords. Try again in {Math.Ceiling(remaining.TotalMinutes)} minutes." });

        try
        {
            var acc = await _db.UserAccounts.Include(a => a.Customer)
                .FirstOrDefaultAsync(a => a.Username.ToLower() == username.ToLower() && a.IsActive && a.CustomerId != null);
            if (acc == null || !_accounts.VerifyPassword(acc, r.Password))
            {
                _attempts.RecordFailure(username);
                return Unauthorized(new { error = "Incorrect username or password." });
            }
            _attempts.Reset(username);
            if (acc.Customer is not { IsActive: true }) return Unauthorized(new { error = "This account is not active. Please contact us." });

            if (acc.TwoFactorEnabled && !string.IsNullOrEmpty(acc.TwoFactorSecret))
                return Ok(new ApiAuthResponse(null, null, null, true, _twoFactor.CreateLoginToken(acc.AccountId, null)));
            return Ok(await IssueAsync(acc));
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "API login failed unexpectedly");
            return StatusCode(500, new { error = "We couldn't log you in just now. Please try again." });
        }
    }

    [HttpPost("two-factor"), EnableRateLimiting("sensitive")]
    public async Task<IActionResult> TwoFactor(ApiTwoFactorRequest r)
    {
        if (!_twoFactor.TryReadLoginToken(r.Challenge, out var accountId, out _))
            return Unauthorized(new { error = "Your login timed out. Please log in again." });
        try
        {
            var acc = await _db.UserAccounts.Include(a => a.Customer)
                .FirstOrDefaultAsync(a => a.AccountId == accountId && a.IsActive && a.CustomerId != null);
            if (acc?.TwoFactorSecret == null || !acc.TwoFactorEnabled || acc.Customer is not { IsActive: true })
                return Unauthorized(new { error = "Please log in again." });
            if (!_twoFactor.VerifyCode(_twoFactor.Decrypt(acc.TwoFactorSecret), r.Code))
                return Unauthorized(new { error = "That code isn't right or has expired." });
            return Ok(await IssueAsync(acc));
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "API two-factor check failed unexpectedly");
            return StatusCode(500, new { error = "We couldn't check your code just now. Please try again." });
        }
    }

    [HttpPost("register")]
    public async Task<IActionResult> Register(RegisterViewModel m)
    {
        if (!_jwt.IsConfigured) return StatusCode(503, new { error = "Mobile login isn't set up yet on the server." });
        try
        {
            var (account, error) = await _accounts.RegisterCustomerAsync(m);
            if (account == null) { ModelState.AddModelError(nameof(m.Username), error!); return ValidationProblem(ModelState); }
            return Ok(await IssueAsync(account));
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "API registration failed");
            return StatusCode(500, new { error = "We couldn't create your account just now. Please try again." });
        }
    }

    private async Task<ApiAuthResponse> IssueAsync(UserAccount acc)
    {
        acc.LastLogin = Clock.Now;
        await _db.SaveChangesAsync();
        var token = _jwt.Create(acc.AccountId, acc.CustomerId!.Value, TokenLifetime);
        return new ApiAuthResponse(token, DateTimeOffset.UtcNow.Add(TokenLifetime), acc.Customer!.FirstName, false, null);
    }
}
