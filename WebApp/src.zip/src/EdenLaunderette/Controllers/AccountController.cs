using System.Security.Claims;
using EdenLaunderette.Data;
using EdenLaunderette.Models;
using EdenLaunderette.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;

namespace EdenLaunderette.Controllers;

public class AccountController : Controller
{
    private readonly AppDbContext _db;
    private readonly AccountService _accounts;
    private readonly TwoFactorService _twoFactor;
    private readonly LoginAttemptTracker _attempts;
    private readonly ILogger<AccountController> _log;

    public AccountController(AppDbContext db, AccountService accounts, TwoFactorService twoFactor, LoginAttemptTracker attempts, ILogger<AccountController> log)
    { _db = db; _accounts = accounts; _twoFactor = twoFactor; _attempts = attempts; _log = log; }

    [HttpGet]
    public IActionResult Register() => View(new RegisterViewModel());

    [HttpPost]
    public async Task<IActionResult> Register(RegisterViewModel m)
    {
        if (!ModelState.IsValid) return View(m);
        try
        {
            var (account, error) = await _accounts.RegisterCustomerAsync(m);
            if (account == null) { ModelState.AddModelError(nameof(m.Username), error!); return View(m); }
            await SignInAsync(account, "Customer", account.Customer!.FirstName);
            return RedirectToAction("Place", "Order");
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Registration failed for {Username}", m.Username);
            ModelState.AddModelError("", "We couldn't create your account just now. Please try again in a moment.");
            return View(m);
        }
    }

    [HttpGet]
    public IActionResult Login(string? returnUrl = null) => View(new LoginViewModel { ReturnUrl = returnUrl });

    [HttpPost, EnableRateLimiting("sensitive")]
    public async Task<IActionResult> Login(LoginViewModel m)
    {
        if (!ModelState.IsValid) return View(m);

        var username = m.Username.Trim();
        if (_attempts.IsLocked(username, out var remaining))
        {
            ModelState.AddModelError("", $"Too many wrong passwords. This account is locked for another {Math.Ceiling(remaining.TotalMinutes)} minutes.");
            return View(m);
        }

        try
        {
            var u = username.ToLower();
            var acc = await _db.UserAccounts.Include(a => a.Customer).Include(a => a.Employee)
                .FirstOrDefaultAsync(a => a.Username.ToLower() == u && a.IsActive);

            if (acc == null || !_accounts.VerifyPassword(acc, m.Password))
            {
                _attempts.RecordFailure(username);
                // One message for both cases, so attackers can't tell which usernames exist.
                ModelState.AddModelError("", "Incorrect username or password.");
                return View(m);
            }
            _attempts.Reset(username);

            var problem = CheckUsable(acc);
            if (problem != null) { ModelState.AddModelError("", problem); return View(m); }

            // Password was right. If two factor is on, ask for the code before logging in.
            if (acc.TwoFactorEnabled && !string.IsNullOrEmpty(acc.TwoFactorSecret))
                return View("TwoFactor", new TwoFactorViewModel { Token = _twoFactor.CreateLoginToken(acc.AccountId, m.ReturnUrl) });

            return await CompleteLoginAsync(acc, m.ReturnUrl);
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Login failed unexpectedly");
            ModelState.AddModelError("", "We couldn't log you in just now. Please try again in a moment.");
            return View(m);
        }
    }

    [HttpPost, EnableRateLimiting("sensitive")]
    public async Task<IActionResult> TwoFactor(TwoFactorViewModel m)
    {
        if (!ModelState.IsValid) return View(m);

        if (!_twoFactor.TryReadLoginToken(m.Token, out var accountId, out var returnUrl))
        {
            TempData["Error"] = "Your login timed out. Please log in again.";
            return RedirectToAction(nameof(Login));
        }

        try
        {
            var acc = await _db.UserAccounts.Include(a => a.Customer).Include(a => a.Employee)
                .FirstOrDefaultAsync(a => a.AccountId == accountId && a.IsActive);
            if (acc == null || CheckUsable(acc) != null || !acc.TwoFactorEnabled || string.IsNullOrEmpty(acc.TwoFactorSecret))
            {
                TempData["Error"] = "Please log in again.";
                return RedirectToAction(nameof(Login));
            }

            if (!_twoFactor.VerifyCode(_twoFactor.Decrypt(acc.TwoFactorSecret), m.Code))
            {
                ModelState.AddModelError(nameof(m.Code), "That code isn't right or has expired. Check the code in your app and try again.");
                return View(m);
            }
            return await CompleteLoginAsync(acc, returnUrl);
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Two-factor check failed unexpectedly");
            TempData["Error"] = "We couldn't check your code just now. Please log in again.";
            return RedirectToAction(nameof(Login));
        }
    }

    [HttpPost, Authorize]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return RedirectToAction("Index", "Home");
    }

    // Customers can keep their own details up to date.
    [HttpGet, Authorize(Roles = AppRoles.Customer)]
    public async Task<IActionResult> Profile()
    {
        var c = await _db.Customers.AsNoTracking().Include(x => x.Addresses).FirstOrDefaultAsync(x => x.CustomerId == CustomerId);
        if (c == null) return NotFound();
        ViewBag.Addresses = c.Addresses.OrderBy(a => a.AddressId).ToList();
        ViewBag.CustomerNumber = c.CustomerNumber;
        return View(new ProfileViewModel { FirstName = c.FirstName, LastName = c.LastName, ContactNumber = c.ContactNumber, Email = c.Email ?? "" });
    }

    [HttpPost, Authorize(Roles = AppRoles.Customer)]
    public async Task<IActionResult> Profile(ProfileViewModel m)
    {
        var c = await _db.Customers.Include(x => x.Addresses).FirstOrDefaultAsync(x => x.CustomerId == CustomerId);
        if (c == null) return NotFound();
        ViewBag.Addresses = c.Addresses.OrderBy(a => a.AddressId).ToList();
        ViewBag.CustomerNumber = c.CustomerNumber;
        if (!ModelState.IsValid) return View(m);

        try
        {
            if (m.ContactNumber != c.ContactNumber && await _db.Customers.AnyAsync(x => x.ContactNumber == m.ContactNumber && x.CustomerId != c.CustomerId))
            {
                ModelState.AddModelError(nameof(m.ContactNumber), "That number is already used by another customer.");
                return View(m);
            }
            c.FirstName = m.FirstName.Trim(); c.LastName = m.LastName.Trim();
            c.ContactNumber = m.ContactNumber; c.Email = m.Email.Trim(); c.UpdatedAt = Clock.Now;
            await _db.SaveChangesAsync();
            TempData["Success"] = "Your details have been updated.";
            return RedirectToAction(nameof(Profile));
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Profile update failed for customer {CustomerId}", CustomerId);
            ModelState.AddModelError("", "We couldn't save your details. Please try again.");
            return View(m);
        }
    }

    [HttpGet]
    public IActionResult AccessDenied() => View();

    private int CustomerId => int.Parse(User.FindFirstValue("CustomerId") ?? "0");

    private static string? CheckUsable(UserAccount a)
    {
        if (a.EmployeeId != null && a.Employee is { IsActive: true }) return null;
        if (a.CustomerId != null && a.Customer is { IsActive: true }) return null;
        return "This account is not active. Please contact us.";
    }

    private async Task<IActionResult> CompleteLoginAsync(UserAccount acc, string? returnUrl)
    {
        acc.LastLogin = Clock.Now;
        await _db.SaveChangesAsync();

        var role = acc.Employee?.EmployeeRole ?? "Customer";
        await SignInAsync(acc, role, acc.Employee?.FirstName ?? acc.Customer!.FirstName);

        if (Url.IsLocalUrl(returnUrl)) return Redirect(returnUrl!);
        if (role == AppRoles.Driver) return RedirectToAction("Index", "Driver");
        if (AppRoles.StaffArea.Split(',').Contains(role)) return RedirectToAction("Index", "Staff");
        return role == "Customer" ? RedirectToAction("History", "Order") : RedirectToAction("Index", "Home");
    }

    private async Task SignInAsync(UserAccount a, string role, string displayName)
    {
        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, a.AccountId.ToString()),
            new(ClaimTypes.Name, displayName),
            new(ClaimTypes.Role, role),
            new("2fa", a.TwoFactorEnabled ? "true" : "false")
        };
        if (a.CustomerId.HasValue) claims.Add(new Claim("CustomerId", a.CustomerId.Value.ToString()));
        if (a.EmployeeId.HasValue) claims.Add(new Claim("EmployeeId", a.EmployeeId.Value.ToString()));
        var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
        await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(identity));
    }
}
