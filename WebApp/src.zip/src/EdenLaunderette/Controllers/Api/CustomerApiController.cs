using System.Security.Claims;
using EdenLaunderette.Data;
using EdenLaunderette.Models;
using EdenLaunderette.Models.Api;
using EdenLaunderette.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EdenLaunderette.Controllers.Api;

// A logged in customer's own data. Every query is filtered by the customer id inside their token.
[ApiController, IgnoreAntiforgeryToken, Route("api")]
[Authorize(AuthenticationSchemes = ApiAuthHandler.SchemeName, Roles = AppRoles.Customer)]
public class CustomerApiController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly OrderService _orders;
    private readonly ILogger<CustomerApiController> _log;
    public CustomerApiController(AppDbContext db, OrderService orders, ILogger<CustomerApiController> log)
    { _db = db; _orders = orders; _log = log; }

    private int CustomerId => int.Parse(User.FindFirstValue("CustomerId")!);

    [HttpGet("me")]
    public async Task<IActionResult> Me()
    {
        var c = await _db.Customers.AsNoTracking().FirstOrDefaultAsync(x => x.CustomerId == CustomerId);
        return c == null ? NotFound() : Ok(new ProfileDto(c.FirstName, c.LastName, c.ContactNumber, c.Email, c.CustomerNumber));
    }

    [HttpGet("orders")]
    public async Task<IActionResult> Orders()
    {
        var list = await _db.Orders.AsNoTracking().Where(o => o.CustomerId == CustomerId).OrderByDescending(o => o.ReceivedAt).ToListAsync();
        return Ok(list.Select(ApiMapper.Summary));
    }

    [HttpGet("orders/{number}")]
    public async Task<IActionResult> Order(string number)
    {
        var order = await _db.Orders.AsNoTracking()
            .Include(o => o.Items).ThenInclude(i => i.Services).ThenInclude(s => s.Service)
            .Include(o => o.StatusHistory).Include(o => o.Payments).Include(o => o.CollectionDeliveries)
            .FirstOrDefaultAsync(o => o.OrderNumber == number && o.CustomerId == CustomerId);
        return order == null ? NotFound(new { error = "We couldn't find that order." }) : Ok(ApiMapper.Detail(order));
    }

    [HttpPost("orders")]
    public async Task<IActionResult> Place(PlaceOrderViewModel m)
    {
        var services = await _orders.ActiveServicesAsync();
        OrderService.CheckServices(m, services, ModelState);
        if (!ModelState.IsValid) return ValidationProblem(ModelState);

        try
        {
            var online = await _orders.OnlineEmployeeIdAsync();
            if (online == null) return StatusCode(503, new { error = "Online ordering isn't set up yet. Please contact us." });
            var order = await _orders.PlaceAsync(CustomerId, online.Value, m, services, "Order placed in the mobile app by the customer.");
            return Ok(ApiMapper.Summary(order));
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "API: failed to place order for customer {CustomerId}", CustomerId);
            return StatusCode(500, new { error = "We couldn't save your order. Nothing was charged. Please try again." });
        }
    }

    [HttpGet("notifications")]
    public async Task<IActionResult> Notifications()
    {
        var list = await _db.Notifications.AsNoTracking().Where(n => n.CustomerId == CustomerId)
            .OrderByDescending(n => n.CreatedAt).Take(50).ToListAsync();
        return Ok(list.Select(n => new NotificationDto(n.NotificationId, n.NotificationType, n.Message, n.CreatedAt)));
    }
}
