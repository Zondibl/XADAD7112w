using System.Text.RegularExpressions;
using EdenLaunderette.Data;
using EdenLaunderette.Models;
using EdenLaunderette.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EdenLaunderette.Controllers;

// Administrators give existing employees a web login.
[Authorize(Roles = AppRoles.Administrator)]
public class AdminController : Controller
{
    private static readonly Regex UsernameRule = new(@"^[A-Za-z0-9._]{3,30}$");
    private static readonly Regex PasswordRule = new(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,100}$");
    private readonly AppDbContext _db;
    private readonly AccountService _accounts;
    private readonly ILogger<AdminController> _log;
    public AdminController(AppDbContext db, AccountService accounts, ILogger<AdminController> log) { _db = db; _accounts = accounts; _log = log; }

    [HttpGet]
    public async Task<IActionResult> Accounts()
    {
        var accounts = await _db.UserAccounts.AsNoTracking().Where(a => a.EmployeeId != null).ToListAsync();
        ViewBag.Usernames = accounts.ToDictionary(a => a.EmployeeId!.Value, a => a.Username);
        ViewBag.TwoFactor = accounts.ToDictionary(a => a.EmployeeId!.Value, a => a.TwoFactorEnabled);
        return View(await _db.Employees.AsNoTracking().Where(e => e.IsActive).OrderBy(e => e.EmployeeNumber).ToListAsync());
    }

    [HttpPost]
    public async Task<IActionResult> CreateAccount(int employeeId, string? username, string? password)
    {
        username = username?.Trim();
        if (username == null || !UsernameRule.IsMatch(username))
            return Fail("Use 3-30 letters, numbers, dots or underscores for the username.");
        if (password == null || !PasswordRule.IsMatch(password))
            return Fail("The password needs at least 8 characters, with a capital letter, a small letter and a number.");

        try
        {
            var emp = await _db.Employees.FirstOrDefaultAsync(e => e.EmployeeId == employeeId && e.IsActive);
            if (emp == null) return Fail("That employee wasn't found.");
            if (await _db.UserAccounts.AnyAsync(a => a.EmployeeId == employeeId)) return Fail("That employee already has a login.");
            if (await _db.UserAccounts.AnyAsync(a => a.Username.ToLower() == username.ToLower())) return Fail("That username is taken.");

            var acc = new UserAccount { EmployeeId = employeeId, Username = username };
            _accounts.SetPassword(acc, password);
            _db.UserAccounts.Add(acc);
            await _db.SaveChangesAsync();
            TempData["Success"] = $"Login created for {emp.FirstName} {emp.LastName}.";
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Creating staff login failed for employee {EmployeeId}", employeeId);
            return Fail("The login wasn't created. Please try again.");
        }
        return RedirectToAction(nameof(Accounts));
    }

    // For a staff member who forgot their password: set a new one .
    [HttpPost]
    public async Task<IActionResult> ResetPassword(int employeeId, string? password)
    {
        if (password == null || !PasswordRule.IsMatch(password))
            return Fail("The password needs at least 8 characters, with a capital letter, a small letter and a number.");
        try
        {
            var acc = await _db.UserAccounts.FirstOrDefaultAsync(a => a.EmployeeId == employeeId);
            if (acc == null) return Fail("That employee doesn't have a login.");
            _accounts.SetPassword(acc, password);
            await _db.SaveChangesAsync();
            TempData["Success"] = $"Password reset for {acc.Username}. Tell them in person and ask them to change it after logging in.";
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Resetting password failed for employee {EmployeeId}", employeeId);
            return Fail("The password wasn't reset. Please try again.");
        }
        return RedirectToAction(nameof(Accounts));
    }

    // For a staff member who lost their phone: They will be asked to set two-factor up again at their next login.
    [HttpPost]
    public async Task<IActionResult> ResetTwoFactor(int employeeId)
    {
        try
        {
            var acc = await _db.UserAccounts.FirstOrDefaultAsync(a => a.EmployeeId == employeeId);
            if (acc == null) return Fail("That employee doesn't have a login.");
            acc.TwoFactorEnabled = false;
            acc.TwoFactorSecret = null;
            await _db.SaveChangesAsync();
            TempData["Success"] = $"Two-factor reset for {acc.Username}. They'll set it up again at their next login.";
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Resetting two-factor failed for employee {EmployeeId}", employeeId);
            return Fail("The reset didn't work. Please try again.");
        }
        return RedirectToAction(nameof(Accounts));
    }

    private IActionResult Fail(string message)
    {
        TempData["Error"] = message;
        return RedirectToAction(nameof(Accounts));
    }
}
