using EdenLaunderette.Models;
using EdenLaunderette.Services;
using Xunit;

namespace EdenLaunderette.Tests;

public class PaymentTests
{
    private static Payment P(int id, string status, decimal amount) => new() { PaymentId = id, PaymentStatus = status, Amount = amount, PaymentMethod = "Cash", ReceiptNumber = $"REC-{id:D6}" };

    [Fact]
    public void Only_paid_payments_count_as_money_received()
    {
        var payments = new[] { P(1, "Paid", 100m), P(2, "Pending", 500m), P(3, "Failed", 40m), P(4, "Refunded", 30m), P(5, "Paid", 25m) };
        Assert.Equal(125m, PaymentRules.PaidTotal(payments));
    }

    [Fact]
    public void The_oldest_pending_payment_is_the_one_that_gets_paid()
    {
        var payments = new[] { P(7, "Pending", 50m), P(3, "Pending", 80m), P(1, "Paid", 10m) };
        Assert.Equal(3, PaymentRules.NextPending(payments)!.PaymentId);
    }

    [Fact]
    public void No_pending_payment_means_a_new_one_is_created()
        => Assert.Null(PaymentRules.NextPending(new[] { P(1, "Paid", 10m), P(2, "Failed", 5m) }));

    [Theory]
    [InlineData("Cash")]
    [InlineData("Card")]
    [InlineData("EFT")]
    public void Customers_can_choose_cash_card_or_eft(string method)
    {
        var m = new PlaceOrderViewModel { ExpectedCompletionDate = DateOnly.FromDateTime(Clock.Now.Date.AddDays(1)), PaymentMethod = method };
        m.Items = new() { new OrderItemInput { ItemType = "Shirt", Quantity = 1, ServiceId = 1 } };
        Assert.Equal(0, TestHelpers.Validate(m).Count);
    }

    [Theory]
    [InlineData("Online")]   // no payment provider connected yet
    [InlineData("Bitcoin")]
    [InlineData("")]
    [InlineData("cash")]     // exact spelling is required
    public void Other_payment_methods_are_rejected(string method)
    {
        var m = new PlaceOrderViewModel { ExpectedCompletionDate = DateOnly.FromDateTime(Clock.Now.Date.AddDays(1)), PaymentMethod = method };
        m.Items = new() { new OrderItemInput { ItemType = "Shirt", Quantity = 1, ServiceId = 1 } };
        Assert.True(TestHelpers.Validate(m).Count > 0);
    }

    [Fact]
    public void The_default_payment_method_is_cash()
        => Assert.Equal("Cash", new PlaceOrderViewModel().PaymentMethod);
}
