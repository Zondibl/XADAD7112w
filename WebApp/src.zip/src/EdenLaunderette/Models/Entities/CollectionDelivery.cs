namespace EdenLaunderette.Models;

public class CollectionDelivery
{
    public int CollectionDeliveryId { get; set; }
    public int OrderId { get; set; }
    public int? EmployeeId { get; set; }
    public int AddressId { get; set; }
    public string TransactionType { get; set; } = "Collection"; // Collection or Delivery
    public string Status { get; set; } = "Scheduled";
    public DateTime ScheduledDatetime { get; set; }
    public DateTime? ActualDatetime { get; set; }
    public string? ProofOfDelivery { get; set; }
    public string? Notes { get; set; }

    public CustomerAddress Address { get; set; } = null!;
    public Order Order { get; set; } = null!;
}
