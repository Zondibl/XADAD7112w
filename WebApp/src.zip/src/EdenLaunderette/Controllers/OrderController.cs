using System.Security.Claims;
using EdenLaunderette.Data;
using EdenLaunderette.Models;
using EdenLaunderette.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EdenLaunderette.Controllers;

[Authorize(Roles = AppRoles.Customer)]
public class OrderController : Controller
{
    private readonly AppDbContext _db;
    private readonly OrderService _orders;
    private readonly ILogger<OrderController> _log;
    public OrderController(AppDbContext db, OrderService orders, ILogger<OrderController> log) { _db = db; _orders = orders; _log = log; }

    private int CustomerId => int.Parse(User.FindFirstValue("CustomerId")!);

    [HttpGet]
    public async Task<IActionResult> Place()
    {
        await LoadServicesAsync();
        var vm = new PlaceOrderViewModel { ExpectedCompletionDate = DateOnly.FromDateTime(Clock.Now.Date.AddDays(1)) };

        // Pre fill the customer's saved address so they don't retype it.
        var saved = await _db.CustomerAddresses.AsNoTracking().Where(a => a.CustomerId == CustomerId)
            .OrderByDescending(a => a.IsDefault).ThenByDescending(a => a.AddressId).FirstOrDefaultAsync();
        if (saved != null)
        {
            vm.AddressLine1 = saved.AddressLine1; vm.Suburb = saved.Suburb; vm.City = saved.City;
            vm.Province = saved.Province ?? vm.Province; vm.PostalCode = saved.PostalCode;
        }
        return View(vm);
    }

    [HttpPost]
    public async Task<IActionResult> Place(PlaceOrderViewModel m)
    {
        var services = await _orders.ActiveServicesAsync();
        OrderService.CheckServices(m, services, ModelState);
        if (!ModelState.IsValid) return Redisplay(m, services);

        try
        {
            var onlineEmployeeId = await _orders.OnlineEmployeeIdAsync();
            if (onlineEmployeeId == null)
            {
                ModelState.AddModelError("", "Online ordering isn't set up yet. Please contact us and we'll log your order.");
                return Redisplay(m, services);
            }
            var order = await _orders.PlaceAsync(CustomerId, onlineEmployeeId.Value, m, services, "Order placed online by the customer.");
            return RedirectToAction(nameof(Confirmation), new { id = order.OrderNumber });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Failed to place order for customer {CustomerId}", CustomerId);
            ModelState.AddModelError("", "We couldn't save your order. Nothing was charged. Please try again, or contact us and we'll log it for you.");
            return Redisplay(m, services);
        }
    }

    [HttpGet]
    public async Task<IActionResult> Confirmation(string id)
    {
        var order = await FindOwnOrderAsync(id, includeDetails: false);
        return order == null ? NotFound() : View(order);
    }

    [HttpGet]
    public async Task<IActionResult> History()
    {
        var orders = await _db.Orders.AsNoTracking()
            .Where(o => o.CustomerId == CustomerId).OrderByDescending(o => o.ReceivedAt).ToListAsync();
        return View(orders);
    }

    [HttpGet]
    public async Task<IActionResult> Details(string id)
    {
        var order = await FindOwnOrderAsync(id, includeDetails: true);
        return order == null ? NotFound() : View(order);
    }

    [HttpGet]
    public async Task<IActionResult> Notifications()
    {
        var list = await _db.Notifications.AsNoTracking().Where(n => n.CustomerId == CustomerId)
            .OrderByDescending(n => n.CreatedAt).Take(50).ToListAsync();
        return View(list);
    }

    [HttpGet]
    public async Task<IActionResult> Invoice(string id)
    {
        var order = await FindOwnOrderAsync(id, includeDetails: true);
        return order == null ? NotFound() : View(order);
    }

    // Always filters by the logged-in customer, so one customer can never open another's order.
    private Task<Order?> FindOwnOrderAsync(string orderNumber, bool includeDetails)
    {
        IQueryable<Order> q = _db.Orders.AsNoTracking().Include(o => o.Payments);
        if (includeDetails)
            q = q.Include(o => o.Customer)
                 .Include(o => o.Items).ThenInclude(i => i.Services).ThenInclude(s => s.Service)
                 .Include(o => o.StatusHistory).Include(o => o.Payments).Include(o => o.CollectionDeliveries);
        return q.FirstOrDefaultAsync(o => o.OrderNumber == orderNumber && o.CustomerId == CustomerId);
    }

    private IActionResult Redisplay(PlaceOrderViewModel m, Dictionary<int, Service> services)
    {
        ViewBag.Services = services.Values.OrderBy(s => s.ServiceName).ToList();
        return View(m);
    }

    private async Task LoadServicesAsync()
        => ViewBag.Services = await _db.Services.AsNoTracking().Where(s => s.IsActive).OrderBy(s => s.ServiceName).ToListAsync();
}
