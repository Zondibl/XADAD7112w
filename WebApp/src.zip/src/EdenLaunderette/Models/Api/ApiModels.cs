using System.ComponentModel.DataAnnotations;

namespace EdenLaunderette.Models.Api;

public class ApiLoginRequest
{
    [Required] public string Username { get; set; } = "";
    [Required] public string Password { get; set; } = "";
}

public class ApiTwoFactorRequest
{
    [Required] public string Challenge { get; set; } = "";
    [Required] public string Code { get; set; } = "";
}

// Either a finished login (Token set) or a request for the two-factor code (RequiresTwoFactor + Challenge).
public record ApiAuthResponse(string? Token, DateTimeOffset? ExpiresAt, string? FirstName, bool RequiresTwoFactor, string? Challenge);

public record ServiceDto(int Id, string Name, string? Description, decimal PricePerItem);

public record OrderSummaryDto(string OrderNumber, string Status, DateTime ReceivedAt, DateOnly ExpectedCompletionDate, decimal EstimatedTotal, decimal? FinalTotal);

public record OrderLineDto(string Item, int Quantity, string Service, decimal UnitPrice, decimal LineTotal);
public record StatusStepDto(string Status, DateTime Date, string? Notes);
public record PaymentDto(string Receipt, decimal Amount, string Method, DateTime Date, string Status);
public record JobDto(string Type, string Status, DateTime Scheduled, string? Notes);

public record OrderDetailDto(OrderSummaryDto Summary, string? SpecialInstructions, IReadOnlyList<OrderLineDto> Lines,
    IReadOnlyList<StatusStepDto> History, IReadOnlyList<PaymentDto> Payments, IReadOnlyList<JobDto> Jobs,
    decimal Paid, decimal Outstanding);

public record NotificationDto(int Id, string Type, string Message, DateTime Created);
public record ProfileDto(string FirstName, string LastName, string ContactNumber, string? Email, string CustomerNumber);

public class ApiTrackRequest
{
    [Required, StringLength(30)] public string OrderNumber { get; set; } = "";
    [Required, StringLength(20)] public string ContactNumber { get; set; } = "";
}
