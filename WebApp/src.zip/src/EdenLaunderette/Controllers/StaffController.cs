using System.Security.Claims;
using EdenLaunderette.Data;
using EdenLaunderette.Models;
using EdenLaunderette.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EdenLaunderette.Controllers;

[Authorize(Roles = AppRoles.StaffArea)]
public class StaffController : Controller
{
    private readonly AppDbContext _db;
    private readonly OrderService _orders;
    private readonly ILogger<StaffController> _log;
    public StaffController(AppDbContext db, OrderService orders, ILogger<StaffController> log) { _db = db; _orders = orders; _log = log; }

    private int EmployeeId => int.Parse(User.FindFirstValue("EmployeeId")!);

    // Orders 

    [HttpGet]
    public async Task<IActionResult> Index(string? status, string? q)
    {
        var query = _db.Orders.AsNoTracking().Include(o => o.Customer).AsQueryable();
        if (!string.IsNullOrWhiteSpace(status) && OrderStatuses.All.Contains(status))
            query = query.Where(o => o.OrderStatus == status);
        if (!string.IsNullOrWhiteSpace(q))
        {
            var term = q.Trim().ToLower();
            query = query.Where(o => o.OrderNumber.ToLower().Contains(term)
                || o.Customer.LastName.ToLower().Contains(term)
                || o.Customer.FirstName.ToLower().Contains(term)
                || o.Customer.ContactNumber.Contains(term));
        }
        ViewBag.Status = status; ViewBag.Query = q;
        return View(await query.OrderByDescending(o => o.ReceivedAt).Take(100).ToListAsync());
    }

    [HttpGet]
    public async Task<IActionResult> Details(int id)
    {
        var order = await _db.Orders.AsNoTracking()
            .Include(o => o.Customer)
            .Include(o => o.Items).ThenInclude(i => i.Services).ThenInclude(s => s.Service)
            .Include(o => o.StatusHistory).Include(o => o.Payments)
            .Include(o => o.CollectionDeliveries).ThenInclude(c => c.Address)
            .FirstOrDefaultAsync(o => o.OrderId == id);
        if (order == null) return NotFound();

        ViewBag.JobStatuses = JobStatuses.All;
        ViewBag.Addresses = await _db.CustomerAddresses.AsNoTracking().Where(a => a.CustomerId == order.CustomerId).OrderBy(a => a.AddressId).ToListAsync();
        await LoadDriversAsync();
        return View(order);
    }

    [HttpPost]
    public async Task<IActionResult> UpdateStatus(int id, string status, string? notes)
    {
        if (!OrderStatuses.All.Contains(status))
        {
            TempData["Error"] = "Choose a valid status.";
            return RedirectToAction(nameof(Details), new { id });
        }
        try
        {
            var order = await _db.Orders.FirstOrDefaultAsync(o => o.OrderId == id);
            if (order == null) return NotFound();
            if (order.OrderStatus == status)
            {
                TempData["Error"] = $"This order is already \"{status}\".";
                return RedirectToAction(nameof(Details), new { id });
            }

            var now = Clock.Now;
            order.OrderStatus = status;
            order.UpdatedAt = now;
            if (status == OrderStatuses.Completed) { order.CompletedAt = now; order.FinalTotal ??= order.EstimatedTotal; }

            _db.OrderStatusHistory.Add(new OrderStatusHistory
            {
                OrderId = id, Status = status, ChangedByEmployeeId = EmployeeId, StatusDate = now, Notes = notes?.Trim()
            });
            _db.Notifications.Add(OrderService.Pending(order.CustomerId, id, "Status Update", $"Your order {order.OrderNumber} is now: {status}."));
            await _db.SaveChangesAsync();
            TempData["Success"] = $"Status updated to \"{status}\". A notification has been queued for the customer.";
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Status update failed for order {OrderId}", id);
            TempData["Error"] = "The status wasn't updated. Please try again.";
        }
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost]
    public async Task<IActionResult> RecordPayment(int id, decimal amount, string method)
    {
        if (amount <= 0 || amount > 100000)
        {
            TempData["Error"] = "Enter an amount greater than R0.00 and under R100 000.";
            return RedirectToAction(nameof(Details), new { id });
        }
        if (!PaymentMethods.All.Contains(method))
        {
            TempData["Error"] = "Choose a payment method.";
            return RedirectToAction(nameof(Details), new { id });
        }
        try
        {
            var order = await _db.Orders.Include(o => o.Payments).FirstOrDefaultAsync(o => o.OrderId == id);
            if (order == null) return NotFound();

            var due = order.FinalTotal ?? order.EstimatedTotal;
            var outstanding = due - PaymentRules.PaidTotal(order.Payments);
            if (amount > outstanding)
            {
                TempData["Error"] = $"That's more than the outstanding amount of {Fmt.Rand(Math.Max(0, outstanding))}.";
                return RedirectToAction(nameof(Details), new { id });
            }

  
            var payment = PaymentRules.NextPending(order.Payments);
            if (payment != null)
            {
                payment.Amount = decimal.Round(amount, 2); payment.PaymentMethod = method; payment.PaymentStatus = "Paid";
                payment.PaymentDate = Clock.Now; payment.RecordedByEmployeeId = EmployeeId; payment.Notes = "Payment received.";
            }
            else
            {
                payment = new Payment
                {
                    OrderId = id,
                    ReceiptNumber = await NumberGenerator.NextAsync(_db.Payments.Select(p => p.ReceiptNumber), "REC-", 6),
                    Amount = decimal.Round(amount, 2), PaymentMethod = method, PaymentStatus = "Paid",
                    PaymentDate = Clock.Now, RecordedByEmployeeId = EmployeeId
                };
                _db.Payments.Add(payment);
            }
            await _db.SaveChangesAsync();
            TempData["Success"] = $"Payment recorded. Receipt {payment.ReceiptNumber}.";
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Payment failed for order {OrderId}", id);
            TempData["Error"] = "The payment wasn't recorded. Please try again.";
        }
        return RedirectToAction(nameof(Details), new { id });
    }

    // Orders that still have money owing.
    [HttpGet]
    public async Task<IActionResult> Payments()
    {
        var orders = await _db.Orders.AsNoTracking().Include(o => o.Customer).Include(o => o.Payments)
            .Where(o => o.OrderStatus != OrderStatuses.Cancelled).OrderByDescending(o => o.ReceivedAt).Take(500).ToListAsync();
        var rows = orders
            .Select(o => (Order: o, Due: o.FinalTotal ?? o.EstimatedTotal,
                          Paid: o.Payments.Where(p => p.PaymentStatus == "Paid").Sum(p => p.Amount)))
            .Where(r => r.Due - r.Paid > 0).ToList();
        return View(rows);
    }

    [HttpGet]
    public async Task<IActionResult> Invoice(int id)
    {
        var order = await _db.Orders.AsNoTracking().Include(o => o.Customer)
            .Include(o => o.Items).ThenInclude(i => i.Services).ThenInclude(s => s.Service)
            .Include(o => o.StatusHistory).Include(o => o.Payments).Include(o => o.CollectionDeliveries)
            .FirstOrDefaultAsync(o => o.OrderId == id);
        return order == null ? NotFound() : View(order);
    }

    // Staff creating an order (walk-in customers)

    [HttpGet]
    public async Task<IActionResult> FindCustomer(string? q)
    {
        var query = _db.Customers.AsNoTracking().Where(c => c.IsActive);
        if (!string.IsNullOrWhiteSpace(q))
        {
            var term = q.Trim().ToLower();
            query = query.Where(c => c.FirstName.ToLower().Contains(term) || c.LastName.ToLower().Contains(term)
                || c.ContactNumber.Contains(term) || c.CustomerNumber.ToLower().Contains(term));
        }
        ViewBag.Query = q;
        return View(await query.OrderBy(c => c.LastName).ThenBy(c => c.FirstName).Take(20).ToListAsync());
    }

    [HttpPost]
    public async Task<IActionResult> CreateCustomer(NewCustomerViewModel m)
    {
        if (!ModelState.IsValid)
        {
            TempData["Error"] = string.Join(" ", ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
            return RedirectToAction(nameof(FindCustomer));
        }
        try
        {
            var existing = await _db.Customers.AsNoTracking().FirstOrDefaultAsync(c => c.ContactNumber == m.ContactNumber);
            if (existing != null)
            {
                TempData["Error"] = $"{existing.FirstName} {existing.LastName} already uses that number. Search for them below instead of adding them again.";
                return RedirectToAction(nameof(FindCustomer), new { q = m.ContactNumber });
            }
            var now = Clock.Now;
            var customer = new Customer
            {
                CustomerNumber = await NumberGenerator.NextAsync(_db.Customers.Select(c => c.CustomerNumber), "CUS-", 5),
                FirstName = m.FirstName.Trim(), LastName = m.LastName.Trim(), ContactNumber = m.ContactNumber,
                Email = string.IsNullOrWhiteSpace(m.Email) ? null : m.Email.Trim(),
                DateRegistered = DateOnly.FromDateTime(now), CreatedAt = now, UpdatedAt = now
            };
            _db.Customers.Add(customer); 
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(NewOrder), new { customerId = customer.CustomerId });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Creating walk-in customer failed");
            TempData["Error"] = "The customer wasn't saved. Please try again.";
            return RedirectToAction(nameof(FindCustomer));
        }
    }

    [HttpGet]
    public async Task<IActionResult> NewOrder(int customerId)
    {
        var customer = await _db.Customers.AsNoTracking().FirstOrDefaultAsync(c => c.CustomerId == customerId && c.IsActive);
        if (customer == null) return NotFound();

        var vm = new StaffOrderViewModel { CustomerId = customerId, ExpectedCompletionDate = DateOnly.FromDateTime(Clock.Now.Date) };
        var saved = await _db.CustomerAddresses.AsNoTracking().Where(a => a.CustomerId == customerId)
            .OrderByDescending(a => a.IsDefault).ThenByDescending(a => a.AddressId).FirstOrDefaultAsync();
        if (saved != null)
        {
            vm.AddressLine1 = saved.AddressLine1; vm.Suburb = saved.Suburb; vm.City = saved.City;
            vm.Province = saved.Province ?? vm.Province; vm.PostalCode = saved.PostalCode;
        }
        ViewBag.Customer = customer;
        await LoadServicesAsync();
        return View(vm);
    }

    [HttpPost]
    public async Task<IActionResult> NewOrder(StaffOrderViewModel m)
    {
        var customer = await _db.Customers.AsNoTracking().FirstOrDefaultAsync(c => c.CustomerId == m.CustomerId && c.IsActive);
        if (customer == null) return NotFound();

        var services = await _orders.ActiveServicesAsync();
        OrderService.CheckServices(m, services, ModelState);
        if (!ModelState.IsValid) return Redisplay(m, customer, services);

        try
        {
            var order = await _orders.PlaceAsync(m.CustomerId, EmployeeId, m, services, "Order logged by staff at the counter.");
            TempData["Success"] = $"Order {order.OrderNumber} created for {customer.FirstName} {customer.LastName}.";
            return RedirectToAction(nameof(Details), new { id = order.OrderId });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Staff failed to create an order for customer {CustomerId}", m.CustomerId);
            ModelState.AddModelError("", "The order wasn't saved. Please try again.");
            return Redisplay(m, customer, services);
        }
    }

    // Collections & deliveries 

    [HttpGet]
    public async Task<IActionResult> Schedule(string? range, string? type)
    {
        range ??= "active";
        var today = Clock.Now.Date;
        var q = _db.CollectionDeliveries.AsNoTracking()
            .Include(j => j.Address).Include(j => j.Order).ThenInclude(o => o.Customer).AsQueryable();
        q = range switch
        {
            "today" => q.Where(j => j.ScheduledDatetime >= today && j.ScheduledDatetime < today.AddDays(1)),
            "tomorrow" => q.Where(j => j.ScheduledDatetime >= today.AddDays(1) && j.ScheduledDatetime < today.AddDays(2)),
            "all" => q,
            _ => q.Where(j => j.Status == "Scheduled" || j.Status == "Assigned" || j.Status == "In Progress")
        };
        if (type == "Collection" || type == "Delivery") q = q.Where(j => j.TransactionType == type);

        ViewBag.Range = range; ViewBag.Type = type;
        ViewBag.JobStatuses = JobStatuses.All;
        await LoadDriversAsync();
        return View(await q.OrderBy(j => j.ScheduledDatetime).Take(200).ToListAsync());
    }

    [HttpPost]
    public async Task<IActionResult> UpdateJob(int id, string status, DateTime? scheduled, int? employeeId, string? proof, string? notes, int? orderId)
    {
        IActionResult Back(string? message = null, bool ok = false)
        {
            if (message != null) TempData[ok ? "Success" : "Error"] = message;
            
            return orderId != null ? RedirectToAction(nameof(Details), new { id = orderId }) : RedirectToAction(nameof(Schedule));
        }

        if (!JobStatuses.All.Contains(status)) return Back("Choose a valid status.");
        try
        {
            var job = await _db.CollectionDeliveries.Include(j => j.Order).FirstOrDefaultAsync(j => j.CollectionDeliveryId == id);
            if (job == null) return NotFound();

            if (employeeId != null && !await IsActiveDriverAsync(employeeId.Value)) return Back("Choose one of the delivery drivers.");
            if (status == "Scheduled" && employeeId != null) status = "Assigned"; // choosing a driver means it's assigned
            if ((status == "Assigned" || status == "In Progress") && employeeId == null) return Back("Choose a driver first.");
            if (status == "Completed" && job.TransactionType == "Delivery" && string.IsNullOrWhiteSpace(proof) && string.IsNullOrWhiteSpace(job.ProofOfDelivery))
                return Back("Record proof of delivery, for example who received the laundry.");
            if (scheduled != null && (scheduled < Clock.Now.AddDays(-1) || scheduled > Clock.Now.AddDays(365)))
                return Back("Choose a date and time within the next year.");

            var statusChanged = job.Status != status;
            var timeChanged = scheduled != null && scheduled != job.ScheduledDatetime;
            job.Status = status;
            job.EmployeeId = employeeId;
            if (scheduled != null) job.ScheduledDatetime = scheduled.Value;
            if (!string.IsNullOrWhiteSpace(proof)) job.ProofOfDelivery = proof.Trim();
            if (!string.IsNullOrWhiteSpace(notes)) job.Notes = notes.Trim();
            if (status == "Completed" && job.ActualDatetime == null) job.ActualDatetime = Clock.Now;

            var note = OrderService.JobUpdate(job, job.Order.OrderNumber, job.Order.CustomerId, statusChanged, timeChanged);
            if (note != null) _db.Notifications.Add(note);
            await _db.SaveChangesAsync();
            return Back($"{job.TransactionType} updated.", ok: true);
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Updating collection/delivery {JobId} failed", id);
            return Back("The change wasn't saved. Please try again.");
        }
    }

    [HttpPost]
    public async Task<IActionResult> AddJob(ScheduleViewModel m)
    {
        IActionResult Back(string message) { TempData["Error"] = message; return RedirectToAction(nameof(Details), new { id = m.OrderId }); }

        if (!ModelState.IsValid)
            return Back(string.Join(" ", ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage)));
        try
        {
            var order = await _db.Orders.FirstOrDefaultAsync(o => o.OrderId == m.OrderId);
            if (order == null) return NotFound();
            if (m.EmployeeId != null && !await IsActiveDriverAsync(m.EmployeeId.Value)) return Back("Choose one of the delivery drivers.");

            var now = Clock.Now;
            var job = new CollectionDelivery
            {
                OrderId = order.OrderId, TransactionType = m.TransactionType, EmployeeId = m.EmployeeId,
                Status = m.EmployeeId == null ? "Scheduled" : "Assigned",
                ScheduledDatetime = m.ScheduledDatetime, Notes = m.Notes?.Trim()
            };
            if (m.AddressId == 0)
                job.Address = await _orders.FindOrCreateAddressAsync(order.CustomerId, m.AddressLine1!, m.Suburb!, m.City, m.Province, m.PostalCode, now);
            else if (await _db.CustomerAddresses.AnyAsync(a => a.AddressId == m.AddressId && a.CustomerId == order.CustomerId))
                job.AddressId = m.AddressId;
            else
                return Back("That address doesn't belong to this customer.");

            _db.CollectionDeliveries.Add(job);
            var note = OrderService.JobUpdate(job, order.OrderNumber, order.CustomerId, statusChanged: false, timeChanged: true);
            if (note != null) _db.Notifications.Add(note);
            await _db.SaveChangesAsync();
            TempData["Success"] = $"{m.TransactionType} scheduled.";
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Scheduling a {Type} for order {OrderId} failed", m.TransactionType, m.OrderId);
            return Back("It wasn't scheduled. Please try again.");
        }
        return RedirectToAction(nameof(Details), new { id = m.OrderId });
    }


    private Task<bool> IsActiveDriverAsync(int employeeId)
        => _db.Employees.AnyAsync(e => e.EmployeeId == employeeId && e.IsActive && e.EmployeeRole == AppRoles.Driver);

    private async Task LoadDriversAsync()
    {
        ViewBag.Drivers = await _db.Employees.AsNoTracking()
            .Where(e => e.IsActive && e.EmployeeRole == AppRoles.Driver).OrderBy(e => e.FirstName).ToListAsync();
        ViewBag.EmployeeNames = await _db.Employees.AsNoTracking().ToDictionaryAsync(e => e.EmployeeId, e => e.FirstName + " " + e.LastName);
    }

    private async Task LoadServicesAsync()
        => ViewBag.Services = await _db.Services.AsNoTracking().Where(s => s.IsActive).OrderBy(s => s.ServiceName).ToListAsync();

    private IActionResult Redisplay(StaffOrderViewModel m, Customer customer, Dictionary<int, Service> services)
    {
        ViewBag.Customer = customer;
        ViewBag.Services = services.Values.OrderBy(s => s.ServiceName).ToList();
        return View(m);
    }
}
