using System.Text.RegularExpressions;
using EdenLaunderette.Models;
using Xunit;

namespace EdenLaunderette.Tests;

// The database (database/001_schema.sql) only accepts certain values. These tests read the SQL script and make sure the
// values used in the code are exactly the allowed ones, so a change on either side that would break saving data fails here first.
public class DatabaseContractTests
{
    private static string[] Allowed(string constraint)
    {
        var sql = File.ReadAllText(Path.Combine(TestHelpers.RepoRoot(), "database", "001_schema.sql"));
        var match = Regex.Match(sql, $@"CONSTRAINT\s+{constraint}\s+CHECK\s*\(\s*\w+\s+IN\s*\(([^)]*)\)", RegexOptions.IgnoreCase);
        Assert.True(match.Success, $"Couldn't find {constraint} in 001_schema.sql");
        return Regex.Matches(match.Groups[1].Value, "'([^']*)'").Select(m => m.Groups[1].Value).ToArray();
    }

    private static void SameValues(string[] expected, string[] actual)
        => Assert.True(new HashSet<string>(expected).SetEquals(actual), $"Expected [{string.Join(", ", expected)}] but the code has [{string.Join(", ", actual)}]");

    [Fact] public void Order_statuses_match() => SameValues(Allowed("chk_order_status"), OrderStatuses.All);
    [Fact] public void Collection_and_delivery_statuses_match() => SameValues(Allowed("chk_delivery_status"), JobStatuses.All);
    [Fact] public void Payment_methods_match() => SameValues(Allowed("chk_payment_method"), PaymentMethods.All);
    [Fact] public void Employee_roles_match() => SameValues(Allowed("chk_employee_role"), AppRoles.EmployeeRoles.Split(','));
    [Fact] public void Transaction_types_match() => SameValues(Allowed("chk_transaction_type"), new[] { "Collection", "Delivery" });
    [Fact] public void Address_types_include_the_one_the_code_saves() => Assert.True(Allowed("chk_address_type").Contains("Home"));
    [Fact] public void Notification_statuses_include_the_one_the_code_saves() => Assert.True(Allowed("chk_notification_status").Contains("Pending"));
    [Fact] public void Every_customer_payment_choice_is_allowed_by_the_database() => Assert.True(PaymentMethods.CustomerChoices.All(c => Allowed("chk_payment_method").Contains(c)));
    [Fact] public void Payment_statuses_include_pending_and_paid() { Assert.True(Allowed("chk_payment_status").Contains("Pending")); Assert.True(Allowed("chk_payment_status").Contains("Paid")); }
    [Fact] public void Payment_statuses_include_the_one_the_code_saves() => Assert.True(Allowed("chk_payment_status").Contains("Paid"));
}
