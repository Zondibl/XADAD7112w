using System.Text;
using EdenLaunderette.Services;
using Xunit;

namespace EdenLaunderette.Tests;

public class TwoFactorServiceTests
{
    // Official test values from RFC 6238 (the standard authenticator apps follow), 8 digits, SHA-1.
    [Theory]
    [InlineData(59L, "94287082")]
    [InlineData(1111111109L, "07081804")]
    [InlineData(1111111111L, "14050471")]
    [InlineData(1234567890L, "89005924")]
    [InlineData(2000000000L, "69279037")]
    [InlineData(20000000000L, "65353130")]
    public void Code_matches_the_RFC_6238_test_vectors(long unixTime, string expected)
    {
        var key = Encoding.ASCII.GetBytes("12345678901234567890");
        Assert.Equal(expected, TwoFactorService.Code(key, unixTime / 30, 8));
    }

    [Fact]
    public void Base32_round_trips_and_matches_the_known_encoding()
    {
        var key = Encoding.ASCII.GetBytes("12345678901234567890");
        Assert.Equal("GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ", TwoFactorService.Base32Encode(key));
        Assert.True(TwoFactorService.Base32Decode("GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ").SequenceEqual(key));
    }

    [Fact]
    public void A_correct_code_is_accepted_and_spaces_are_ignored()
    {
        var svc = TestHelpers.TwoFactor();
        var secret = svc.NewSecret();
        var now = DateTimeOffset.UtcNow;
        var good = TwoFactorService.Code(TwoFactorService.Base32Decode(secret), now.ToUnixTimeSeconds() / 30, 6);
        Assert.True(svc.VerifyCode(secret, good, now));
        Assert.True(svc.VerifyCode(secret, good.Insert(3, " "), now));
    }

    [Theory]
    [InlineData("")]
    [InlineData("12345")]
    [InlineData("abcdef")]
    [InlineData(null)]
    public void Bad_input_is_rejected(string? code)
    {
        var svc = TestHelpers.TwoFactor();
        Assert.False(svc.VerifyCode(svc.NewSecret(), code));
    }

    [Fact]
    public void A_wrong_code_and_an_old_code_are_rejected()
    {
        var svc = TestHelpers.TwoFactor();
        var secret = svc.NewSecret();
        var key = TwoFactorService.Base32Decode(secret);
        var now = DateTimeOffset.UtcNow;
        var step = now.ToUnixTimeSeconds() / 30;
        var good = TwoFactorService.Code(key, step, 6);
        var wrong = ((int.Parse(good) + 1) % 1_000_000).ToString("D6");
        Assert.False(svc.VerifyCode(secret, wrong, now));
        Assert.False(svc.VerifyCode(secret, TwoFactorService.Code(key, step - 3, 6), now)); // 90 seconds old
    }

    [Fact]
    public void Secrets_are_encrypted_and_tampering_is_detected()
    {
        var svc = TestHelpers.TwoFactor();
        var secret = svc.NewSecret();
        var stored = svc.Encrypt(secret);
        Assert.False(stored.Contains(secret));
        Assert.Equal(secret, svc.Decrypt(stored));

        var bytes = Convert.FromBase64String(stored);
        bytes[^1] ^= 1;
        Assert.ThrowsAny<System.Security.Cryptography.CryptographicException>(() => svc.Decrypt(Convert.ToBase64String(bytes)));
    }

    [Fact]
    public void A_different_key_cannot_read_the_secret()
    {
        var stored = TestHelpers.TwoFactor("key-one").Encrypt("SECRET");
        Assert.ThrowsAny<System.Security.Cryptography.CryptographicException>(() => TestHelpers.TwoFactor("key-two").Decrypt(stored));
    }

    [Fact]
    public void Login_tokens_round_trip_and_garbage_is_rejected()
    {
        var svc = TestHelpers.TwoFactor();
        var token = svc.CreateLoginToken(42, "/Staff");
        Assert.True(svc.TryReadLoginToken(token, out var id, out var ret));
        Assert.Equal(42, id);
        Assert.Equal("/Staff", ret);
        Assert.False(svc.TryReadLoginToken("not-a-token", out _, out _));
    }

    [Fact]
    public void Without_a_key_outside_development_it_reports_not_configured()
        => Assert.False(new TwoFactorService(TestHelpers.Config(), new FakeEnv(),
            Microsoft.AspNetCore.DataProtection.DataProtectionProvider.Create("x"),
            Microsoft.Extensions.Logging.Abstractions.NullLogger<TwoFactorService>.Instance).IsConfigured);
}
