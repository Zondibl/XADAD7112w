using EdenLaunderette.Data;
using EdenLaunderette.Models;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.EntityFrameworkCore;

namespace EdenLaunderette.Services;

// Order creation shared by the customer's "Place an order" page and the staff "New order" page.
public class OrderService
{
    private readonly AppDbContext _db;
    private readonly IConfiguration _config;
    public OrderService(AppDbContext db, IConfiguration config) { _db = db; _config = config; }

    public Task<Dictionary<int, Service>> ActiveServicesAsync()
        => _db.Services.Where(s => s.IsActive).ToDictionaryAsync(s => s.ServiceId);

    public static void CheckServices(PlaceOrderViewModel m, Dictionary<int, Service> services, ModelStateDictionary state)
    {
        for (var i = 0; i < m.Items.Count; i++)
            if (!services.ContainsKey(m.Items[i].ServiceId))
                state.AddModelError($"Items[{i}].ServiceId", "Choose a service from the list.");
    }

    // The database requires every order to be received by an employee, orders customers place online use a system employee.
    public async Task<int?> OnlineEmployeeIdAsync()
    {
        var number = _config["OnlineOrders:EmployeeNumber"] ?? "EMP-ONLINE";
        return await _db.Employees.Where(e => e.EmployeeNumber == number).Select(e => (int?)e.EmployeeId).FirstOrDefaultAsync();
    }

    public static Notification Pending(int customerId, int? orderId, string type, string message) => new()
    {
        CustomerId = customerId, OrderId = orderId, NotificationType = type, DeliveryChannel = "Email",
        NotificationStatus = "Pending", Message = message, CreatedAt = Clock.Now // Pending: nothing is actually emailed or texted yet
    };

    // The message a customer gets when a collection or delivery changes .
    public static Notification? JobUpdate(CollectionDelivery j, string orderNumber, int customerId, bool statusChanged, bool timeChanged)
    {
        var type = j.TransactionType.ToLowerInvariant();
        string? msg = null;
        if (statusChanged)
            msg = j.Status switch
            {
                "In Progress" => j.TransactionType == "Delivery"
                    ? $"Your laundry (order {orderNumber}) is out for delivery."
                    : $"We're on our way to collect your laundry (order {orderNumber}).",
                "Completed" => $"Your {type} for order {orderNumber} is complete.",
                "Failed" => $"We couldn't complete your {type} for order {orderNumber}. We'll be in touch.",
                "Cancelled" => $"Your {type} for order {orderNumber} was cancelled.",
                _ => null
            };
        if (msg == null && timeChanged)
            msg = $"Your {type} for order {orderNumber} is scheduled for {j.ScheduledDatetime:d MMM yyyy, HH:mm}.";
        return msg == null ? null : Pending(customerId, j.OrderId, j.TransactionType == "Delivery" ? "Delivery Update" : "Collection Update", msg);
    }

    public async Task<Order> PlaceAsync(int customerId, int receivedByEmployeeId, PlaceOrderViewModel m,
        Dictionary<int, Service> services, string historyNote)
    {
        await using var tx = await _db.Database.BeginTransactionAsync();
        var now = Clock.Now;

        var order = new Order
        {
            OrderNumber = await NumberGenerator.NextAsync(_db.Orders.Select(o => o.OrderNumber), "EDN-", 6),
            CustomerId = customerId, ReceivedByEmployeeId = receivedByEmployeeId,
            ReceivedAt = now, CreatedAt = now, UpdatedAt = now,
            ExpectedCompletionDate = m.ExpectedCompletionDate,
            OrderStatus = OrderStatuses.Received,
            SpecialInstructions = m.SpecialInstructions?.Trim()
        };

        // Prices come from the database, never from the browser, so they can't be tampered with.
        decimal total = 0;
        foreach (var input in m.Items)
        {
            var svc = services[input.ServiceId];
            var line = OrderPricing.LineTotal(svc.PricePerItem, input.Quantity);
            total += line;
            var item = new OrderItem { ItemType = input.ItemType.Trim(), Quantity = input.Quantity, ConditionNotes = input.ConditionNotes?.Trim(), CreatedAt = now };
            item.Services.Add(new OrderItemService { ServiceId = svc.ServiceId, Quantity = input.Quantity, UnitPrice = svc.PricePerItem, LineTotal = line });
            order.Items.Add(item);
        }
        order.EstimatedTotal = total;

        order.StatusHistory.Add(new OrderStatusHistory
        {
            Status = OrderStatuses.Received, ChangedByEmployeeId = receivedByEmployeeId, StatusDate = now, Notes = historyNote
        });

        if (m.RequestCollection || m.RequestDelivery)
        {
            var address = await FindOrCreateAddressAsync(customerId, m.AddressLine1!, m.Suburb!, m.City, m.Province, m.PostalCode, now);
            
            if (m.RequestCollection)
                order.CollectionDeliveries.Add(new CollectionDelivery
                {
                    TransactionType = "Collection", Address = address, ScheduledDatetime = now.AddHours(1), Notes = "Provisional time - staff will confirm."
                });
            if (m.RequestDelivery)
                order.CollectionDeliveries.Add(new CollectionDelivery
                {
                    TransactionType = "Delivery", Address = address,
                    ScheduledDatetime = m.ExpectedCompletionDate.ToDateTime(new TimeOnly(17, 0)), Notes = "Provisional time - staff will confirm."
                });
        }

        _db.Orders.Add(order);
        await _db.SaveChangesAsync();

        // Shows how the customer plans to pay. It stays "Pending" until staff record the money.
        if (total > 0)
            _db.Payments.Add(new Payment
            {
                OrderId = order.OrderId,
                ReceiptNumber = await NumberGenerator.NextAsync(_db.Payments.Select(p => p.ReceiptNumber), "REC-", 6),
                Amount = total, PaymentMethod = m.PaymentMethod, PaymentStatus = "Pending", PaymentDate = now,
                RecordedByEmployeeId = receivedByEmployeeId,
                Notes = "Payment method chosen when the order was placed. Awaiting payment."
            });
        _db.Notifications.Add(Pending(customerId, order.OrderId, "Order Received",
            $"Your order {order.OrderNumber} has been received. Estimated total {Fmt.Rand(total)}."));
        await _db.SaveChangesAsync();
        await tx.CommitAsync();
        return order;
    }

    // Reuses an address the customer already has, so the same address isn't saved again and again.
    public async Task<CustomerAddress> FindOrCreateAddressAsync(int customerId, string line1, string suburb, string city, string? province, string? postal, DateTime now)
    {
        line1 = line1.Trim(); suburb = suburb.Trim();
        var existing = await _db.CustomerAddresses.FirstOrDefaultAsync(a => a.CustomerId == customerId
            && a.AddressLine1.ToLower() == line1.ToLower() && a.Suburb != null && a.Suburb.ToLower() == suburb.ToLower());
        if (existing != null) return existing;

        var address = new CustomerAddress
        {
            CustomerId = customerId, AddressType = "Home", AddressLine1 = line1, Suburb = suburb, City = city.Trim(),
            Province = province?.Trim(), PostalCode = postal?.Trim(),
            IsDefault = !await _db.CustomerAddresses.AnyAsync(a => a.CustomerId == customerId), CreatedAt = now
        };
        _db.CustomerAddresses.Add(address);
        return address;
    }
}
