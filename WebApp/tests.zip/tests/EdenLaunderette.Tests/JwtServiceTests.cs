using System.Text;
using Xunit;

namespace EdenLaunderette.Tests;

public class JwtServiceTests
{
    [Fact]
    public void A_fresh_token_is_valid_and_carries_the_ids()
    {
        var jwt = TestHelpers.Jwt();
        var token = jwt.Create(7, 9, TimeSpan.FromHours(1));
        Assert.True(jwt.TryValidate(token, out var account, out var customer));
        Assert.Equal(7, account);
        Assert.Equal(9, customer);
    }

    [Fact]
    public void An_expired_token_is_rejected()
    {
        var jwt = TestHelpers.Jwt();
        var issued = DateTimeOffset.UtcNow.AddHours(-3);
        var token = jwt.Create(1, 1, TimeSpan.FromHours(1), issued);
        Assert.False(jwt.TryValidate(token, out _, out _));
    }

    [Fact]
    public void A_tampered_token_is_rejected()
    {
        var jwt = TestHelpers.Jwt();
        var parts = jwt.Create(1, 1, TimeSpan.FromHours(1)).Split('.');
        // Swap in a payload for a different customer but keep the old signature.
        var forged = Convert.ToBase64String(Encoding.UTF8.GetBytes("{\"iss\":\"EdenLaunderette\",\"sub\":1,\"cid\":2,\"exp\":99999999999}"))
            .TrimEnd('=').Replace('+', '-').Replace('/', '_');
        Assert.False(jwt.TryValidate($"{parts[0]}.{forged}.{parts[2]}", out _, out _));
    }

    [Fact]
    public void A_token_signed_with_another_key_is_rejected()
    {
        var token = TestHelpers.Jwt("another-unit-test-key-that-is-32-chars-long!!").Create(1, 1, TimeSpan.FromHours(1));
        Assert.False(TestHelpers.Jwt().TryValidate(token, out _, out _));
    }

    [Theory]
    [InlineData("")]
    [InlineData("abc")]
    [InlineData("a.b.c")]
    [InlineData(null)]
    public void Garbage_is_rejected(string? token) => Assert.False(TestHelpers.Jwt().TryValidate(token, out _, out _));

    [Fact]
    public void A_short_key_means_not_configured()
        => Assert.False(TestHelpers.Jwt("too-short").IsConfigured);
}
