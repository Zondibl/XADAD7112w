using System.ComponentModel.DataAnnotations;

namespace EdenLaunderette.Models;

public class OrderItemInput
{
    [Required(ErrorMessage = "Enter the item, e.g. Shirt."), StringLength(50, ErrorMessage = "Keep the item name under 50 characters.")]
    [Display(Name = "Item")]
    public string ItemType { get; set; } = "";

    [Range(1, 100, ErrorMessage = "Enter a quantity between 1 and 100.")]
    public int Quantity { get; set; } = 1;

    [Range(1, int.MaxValue, ErrorMessage = "Choose a service.")]
    [Display(Name = "Service")]
    public int ServiceId { get; set; }

    [StringLength(200, ErrorMessage = "Keep notes under 200 characters.")]
    [Display(Name = "Notes (stains, damage)")]
    public string? ConditionNotes { get; set; }
}

public class PlaceOrderViewModel : IValidatableObject
{
    [MinLength(1, ErrorMessage = "Add at least one item.")]
    public List<OrderItemInput> Items { get; set; } = new() { new OrderItemInput() };

    [DataType(DataType.Date)]
    [Display(Name = "Needed by")]
    public DateOnly ExpectedCompletionDate { get; set; }

    [Display(Name = "Collect from my address")]
    public bool RequestCollection { get; set; }

    [Display(Name = "Deliver back to my address")]
    public bool RequestDelivery { get; set; }

    [StringLength(120)] [Display(Name = "Street address")]
    public string? AddressLine1 { get; set; }
    [StringLength(80)] public string? Suburb { get; set; }
    [StringLength(80)] public string City { get; set; } = "Cape Town";
    [StringLength(80)] public string Province { get; set; } = "Western Cape";
    [StringLength(10)] [Display(Name = "Postal code")]
    public string? PostalCode { get; set; }

    [Required(ErrorMessage = "Choose how you'll pay."), RegularExpression("^(Cash|Card|EFT)$", ErrorMessage = "Choose cash, card or EFT.")]
    [Display(Name = "How will you pay?")]
    public string PaymentMethod { get; set; } = "Cash";

    [StringLength(500, ErrorMessage = "Keep instructions under 500 characters.")]
    [Display(Name = "Special instructions")]
    public string? SpecialInstructions { get; set; }

    public IEnumerable<ValidationResult> Validate(ValidationContext ctx)
    {
        if (ExpectedCompletionDate < DateOnly.FromDateTime(Clock.Now.Date))
            yield return new ValidationResult("Choose today's date or a later date.", new[] { nameof(ExpectedCompletionDate) });

        if (RequestCollection || RequestDelivery)
        {
            if (string.IsNullOrWhiteSpace(AddressLine1))
                yield return new ValidationResult("Enter your street address so we can collect or deliver.", new[] { nameof(AddressLine1) });
            if (string.IsNullOrWhiteSpace(Suburb))
                yield return new ValidationResult("Enter your suburb.", new[] { nameof(Suburb) });
        }
    }
}

public class TrackViewModel
{
    [Required(ErrorMessage = "Enter your order number, e.g. EDN-000125.")]
    [StringLength(30)]
    [Display(Name = "Order number")]
    public string OrderNumber { get; set; } = "";

    [Required(ErrorMessage = "Enter the contact number you used for the order.")]
    [StringLength(20)]
    [Display(Name = "Contact number")]
    public string ContactNumber { get; set; } = "";
}

public class StaffOrderViewModel : PlaceOrderViewModel
{
    public int CustomerId { get; set; }
}
