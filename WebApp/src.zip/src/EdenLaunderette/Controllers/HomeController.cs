using EdenLaunderette.Data;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;

namespace EdenLaunderette.Controllers;

public class HomeController : Controller
{
    private readonly AppDbContext _db;
    private readonly IMemoryCache _cache;
    public HomeController(AppDbContext db, IMemoryCache cache) { _db = db; _cache = cache; }

    public IActionResult Index() => View();
    public IActionResult About() => View();
    public IActionResult Faq() => View();
    public IActionResult Contact() => View();

    public async Task<IActionResult> Services()
    {
        // Caching pattern: the price list rarely changes.
        var services = await _cache.GetOrCreateAsync("services:active", async entry =>
        {
            entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(5);
            return await _db.Services.AsNoTracking().Where(s => s.IsActive).OrderBy(s => s.ServiceName).ToListAsync();
        });
        return View(services);
    }

    // Shown when something unexpected goes wrong.
    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        if (HttpContext.Features.Get<IExceptionHandlerPathFeature>()?.Path.StartsWith("/api") == true)
            return StatusCode(500, new { error = "Something went wrong. Please try again." });
        return View();
    }

    // Friendly pages for 404, 403 and other status codes.
    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Status(int code)
    {
        if (HttpContext.Features.Get<IStatusCodeReExecuteFeature>()?.OriginalPath.StartsWith("/api") == true)
            return StatusCode(code, new { error = "That request couldn't be completed." });
        Response.StatusCode = code;
        ViewBag.Code = code;
        ViewBag.Message = code switch
        {
            404 => "We couldn't find that page. The link may be old, or the order number may be wrong.",
            403 => "You don't have access to that page.",
            401 => "Please log in to see that page.",
            429 => "Too many attempts. Please wait a minute and try again.",
            _ => "Something went wrong. Please go back and try again."
        };
        return View();
    }
}
