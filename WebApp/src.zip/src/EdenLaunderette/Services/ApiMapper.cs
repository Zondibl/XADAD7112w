using EdenLaunderette.Models;
using EdenLaunderette.Models.Api;

namespace EdenLaunderette.Services;

public static class ApiMapper
{
    public static OrderSummaryDto Summary(Order o)
        => new(o.OrderNumber, o.OrderStatus, o.ReceivedAt, o.ExpectedCompletionDate, o.EstimatedTotal, o.FinalTotal);

    // Expects the order loaded with Items > Services > Service, StatusHistory, Payments and CollectionDeliveries.
    public static OrderDetailDto Detail(Order o)
    {
        var paid = PaymentRules.PaidTotal(o.Payments);
        return new OrderDetailDto(
            Summary(o), o.SpecialInstructions,
            o.Items.SelectMany(i => i.Services.Select(s => new OrderLineDto(i.ItemType, s.Quantity, s.Service.ServiceName, s.UnitPrice, s.LineTotal))).ToList(),
            o.StatusHistory.OrderBy(h => h.StatusDate).Select(h => new StatusStepDto(h.Status, h.StatusDate, h.Notes)).ToList(),
            o.Payments.OrderBy(p => p.PaymentDate).Select(p => new PaymentDto(p.ReceiptNumber, p.Amount, p.PaymentMethod, p.PaymentDate, p.PaymentStatus)).ToList(),
            o.CollectionDeliveries.OrderBy(c => c.ScheduledDatetime).Select(c => new JobDto(c.TransactionType, c.Status, c.ScheduledDatetime, c.Notes)).ToList(),
            paid, OrderPricing.Outstanding(o.FinalTotal ?? o.EstimatedTotal, new[] { paid }));
    }
}
