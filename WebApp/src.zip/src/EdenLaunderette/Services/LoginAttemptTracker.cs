using System.Collections.Concurrent;

namespace EdenLaunderette.Services;

// Counts wrong passwords per username. After 5 in 15 minutes the account is locked for 15 minutes.
// Kept in memory (resets if the app restarts); the per-IP rate limiter in Program.cs is a second layer.
public class LoginAttemptTracker
{
    public const int MaxAttempts = 5;
    public static readonly TimeSpan Window = TimeSpan.FromMinutes(15);
    private readonly ConcurrentDictionary<string, (int Count, DateTime First, DateTime? LockedUntil)> _attempts = new();
    private readonly Func<DateTime> _now;

    public LoginAttemptTracker() : this(() => DateTime.UtcNow) { }
    public LoginAttemptTracker(Func<DateTime> now) => _now = now;

    public bool IsLocked(string username, out TimeSpan remaining)
    {
        remaining = TimeSpan.Zero;
        if (!_attempts.TryGetValue(Key(username), out var a) || a.LockedUntil is not { } until) return false;
        if (until <= _now()) { _attempts.TryRemove(Key(username), out _); return false; }
        remaining = until - _now();
        return true;
    }

    public void RecordFailure(string username)
    {
        var now = _now();
        _attempts.AddOrUpdate(Key(username),
            _ => (1, now, null),
            (_, a) =>
            {
                if (now - a.First > Window) return (1, now, null); // old failures expire
                var count = a.Count + 1;
                return (count, a.First, count >= MaxAttempts ? now.Add(Window) : a.LockedUntil);
            });
    }

    public void Reset(string username) => _attempts.TryRemove(Key(username), out _);

    private static string Key(string username) => username.Trim().ToLowerInvariant();
}
