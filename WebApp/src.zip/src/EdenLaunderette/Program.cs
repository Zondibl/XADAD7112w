using System.Security.Claims;
using System.Threading.RateLimiting;
using EdenLaunderette.Data;
using EdenLaunderette.Models;
using EdenLaunderette.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

AppContext.SetSwitch("Npgsql.EnableLegacyTimestampBehavior", true);

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews(o => o.Filters.Add(new AutoValidateAntiforgeryTokenAttribute()));

// Database: PostgreSQL (local or in the cloud). SQL injection is prevented because every query is parameterised by EF Core.
builder.Services.AddDbContext<AppDbContext>(opt =>
    opt.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection"))
       .UseSnakeCaseNamingConvention()); // order_id, customer_number  matches the DDL

builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(o =>
    {
        o.LoginPath = "/Account/Login";
        o.AccessDeniedPath = "/Account/AccessDenied";
        o.Cookie.HttpOnly = true;
        o.Cookie.SameSite = SameSiteMode.Lax;
        o.Cookie.SecurePolicy = builder.Environment.IsDevelopment() ? CookieSecurePolicy.SameAsRequest : CookieSecurePolicy.Always;
        o.ExpireTimeSpan = TimeSpan.FromHours(8);
        o.SlidingExpiration = true;
    })
    .AddScheme<AuthenticationSchemeOptions, ApiAuthHandler>(ApiAuthHandler.SchemeName, _ => { }); 
builder.Services.AddAuthorization();
builder.Services.AddDataProtection();
builder.Services.AddMemoryCache();

builder.Services.AddSingleton<TwoFactorService>();
builder.Services.AddSingleton<JwtService>();
builder.Services.AddSingleton<LoginAttemptTracker>();
builder.Services.AddScoped<AccountService>();
builder.Services.AddScoped<OrderService>();

builder.Services.AddRateLimiter(o =>
{
    o.RejectionStatusCode = StatusCodes.Status429TooManyRequests;
    o.AddPolicy("sensitive", ctx => RateLimitPartition.GetFixedWindowLimiter(
        ctx.Connection.RemoteIpAddress?.ToString() ?? "unknown",
        _ => new FixedWindowRateLimiterOptions { PermitLimit = 10, Window = TimeSpan.FromMinutes(1), QueueLimit = 0 }));
});

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    if (app.Configuration.GetValue<bool>("Database:EnsureCreated")) db.Database.EnsureCreated();
    await DbSeeder.SeedAsync(db, app.Configuration);
}

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error"); 
    app.UseHsts();
}
app.UseStatusCodePagesWithReExecute("/Home/Status", "?code={0}"); // friendly 404 / 403 pages
app.UseHttpsRedirection();

app.Use(async (ctx, next) =>
{
    var h = ctx.Response.Headers;
    h["X-Content-Type-Options"] = "nosniff";
    h["X-Frame-Options"] = "DENY";
    h["Referrer-Policy"] = "strict-origin-when-cross-origin";
    h["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()";
    h["Content-Security-Policy"] =
        "default-src 'self'; script-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com; " +
        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; " +
        "img-src 'self' data:; connect-src 'self'" + (app.Environment.IsDevelopment() ? " ws: wss:" : "") +
        "; frame-ancestors 'none'; form-action 'self'; base-uri 'self'";
    await next();
});

app.UseStaticFiles();
app.UseRouting();
app.UseRateLimiter();
app.UseAuthentication();
app.UseAuthorization();

// Employees must have two factor login switched on before they can use anything else.
app.Use(async (ctx, next) =>
{
    var user = ctx.User;
    if (user.Identity?.IsAuthenticated == true && AppRoles.IsEmployee(user) && user.FindFirstValue("2fa") != "true")
    {
        var path = ctx.Request.Path;
        if (!path.StartsWithSegments("/Security") && !path.StartsWithSegments("/Account") && !path.StartsWithSegments("/Home/Error"))
        {
            ctx.Response.Redirect("/Security/Setup");
            return;
        }
    }
    await next();
});

app.MapControllerRoute("default", "{controller=Home}/{action=Index}/{id?}");
app.Run();
