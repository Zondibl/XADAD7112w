namespace EdenLaunderette.Models;

public class Notification
{
    public int NotificationId { get; set; }
    public int CustomerId { get; set; }
    public int? OrderId { get; set; }
    public string NotificationType { get; set; } = "";
    public string DeliveryChannel { get; set; } = "Email"; 
    public string Message { get; set; } = "";
    public string NotificationStatus { get; set; } = "Pending";
    public DateTime? SentAt { get; set; }
    public DateTime CreatedAt { get; set; } = Clock.Now;
}
