using EdenLaunderette.Data;
using EdenLaunderette.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;

namespace EdenLaunderette.Controllers;

// Works without logging in, for customers who only have their order number.
[AllowAnonymous]
public class TrackController : Controller
{
    private readonly AppDbContext _db;
    private readonly ILogger<TrackController> _log;
    public TrackController(AppDbContext db, ILogger<TrackController> log) { _db = db; _log = log; }

    [HttpGet]
    public IActionResult Index() => View(new TrackViewModel());

    [HttpPost, EnableRateLimiting("sensitive")]
    public async Task<IActionResult> Index(TrackViewModel m)
    {
        if (!ModelState.IsValid) return View(m);
        try
        {
            var number = m.OrderNumber.Trim().ToUpperInvariant();
            var phone = new string(m.ContactNumber.Where(char.IsDigit).ToArray());

            var order = await _db.Orders.AsNoTracking()
                .Include(o => o.Customer)
                .Include(o => o.Items).ThenInclude(i => i.Services).ThenInclude(s => s.Service)
                .Include(o => o.StatusHistory).Include(o => o.Payments).Include(o => o.CollectionDeliveries)
                .FirstOrDefaultAsync(o => o.OrderNumber == number && o.Customer.ContactNumber == phone);

            if (order == null)
            {
                // Same message whether the number or the phone was wrong.
                ModelState.AddModelError("", "We couldn't find an order with those details. Check the order number and the contact number, or contact us and we'll look it up.");
                return View(m);
            }
            return View("Result", order);
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Order tracking lookup failed");
            ModelState.AddModelError("", "We couldn't look that up just now. Please try again in a moment.");
            return View(m);
        }
    }
}
