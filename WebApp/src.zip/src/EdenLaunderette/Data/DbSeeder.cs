using EdenLaunderette.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace EdenLaunderette.Data;

public static class DbSeeder
{
    public static async Task SeedAsync(AppDbContext db, IConfiguration config)
    {
        // Only used when the services table is empty.
        if (!await db.Services.AnyAsync())
        {
            db.Services.AddRange(
                new Service { ServiceCode = "WASH", ServiceName = "Washing", Description = "Standard washing service", PricePerItem = 25m },
                new Service { ServiceCode = "IRON", ServiceName = "Ironing", Description = "Professional ironing service", PricePerItem = 20m },
                new Service { ServiceCode = "FOLD", ServiceName = "Folding", Description = "Folding and packaging service", PricePerItem = 10m });
            await db.SaveChangesAsync();
        }

        
        var onlineNo = config["OnlineOrders:EmployeeNumber"] ?? "EMP-ONLINE";
        if (!await db.Employees.AnyAsync(e => e.EmployeeNumber == onlineNo))
        {
            db.Employees.Add(new Employee { EmployeeNumber = onlineNo, FirstName = "Online", LastName = "Orders", EmployeeRole = "Laundry Staff" });
            await db.SaveChangesAsync();
        }

        // First staff login: gives an existing employee (default EMP-001) a username and password.
        var user = config["SeedAdmin:Username"];
        var pass = config["SeedAdmin:Password"];
        var empNo = config["SeedAdmin:EmployeeNumber"] ?? "EMP-001";
        if (string.IsNullOrWhiteSpace(user) || string.IsNullOrWhiteSpace(pass)) return;

        var emp = await db.Employees.FirstOrDefaultAsync(e => e.EmployeeNumber == empNo);
        if (emp == null)
        {
            emp = new Employee { EmployeeNumber = empNo, FirstName = "System", LastName = "Admin", EmployeeRole = "Administrator" };
            db.Employees.Add(emp);
            await db.SaveChangesAsync();
        }
        if (await db.UserAccounts.AnyAsync(a => a.EmployeeId == emp.EmployeeId || a.Username == user)) return;

        var acc = new UserAccount { EmployeeId = emp.EmployeeId, Username = user };
        acc.PasswordHash = new PasswordHasher<UserAccount>().HashPassword(acc, pass);
        db.UserAccounts.Add(acc);
        await db.SaveChangesAsync();
    }
}
