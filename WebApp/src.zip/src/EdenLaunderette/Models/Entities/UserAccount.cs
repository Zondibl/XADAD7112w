namespace EdenLaunderette.Models;

public class UserAccount
{
    [System.ComponentModel.DataAnnotations.Key]
    public int AccountId { get; set; }
   
    public int? CustomerId { get; set; }
    public int? EmployeeId { get; set; }
    public string Username { get; set; } = "";
    public string PasswordHash { get; set; } = "";
    public bool IsActive { get; set; } = true;
    public bool TwoFactorEnabled { get; set; }
    public string? TwoFactorSecret { get; set; } // encrypted by TwoFactorService, never plain text
    public DateTime? LastLogin { get; set; }
    public DateTime CreatedAt { get; set; } = Clock.Now;

    public Customer? Customer { get; set; }
    public Employee? Employee { get; set; }
}
