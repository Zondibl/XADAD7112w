using EdenLaunderette.Models;
using Xunit;

namespace EdenLaunderette.Tests;

public class ValidationTests
{
    private static RegisterViewModel ValidRegistration() => new()
    {
        FirstName = "Thandi", LastName = "Mokoena", ContactNumber = "0712216255", Email = "t@example.com",
        Username = "thandi.m", Password = "Strong#123", ConfirmPassword = "Strong#123"
    };

    [Fact]
    public void A_good_registration_passes() => Assert.Equal(0, TestHelpers.Validate(ValidRegistration()).Count);

    [Theory]
    [InlineData("short1A")]        // too short
    [InlineData("alllowercase1")]  // no capital
    [InlineData("ALLUPPERCASE1")]  // no small letter
    [InlineData("NoNumbersHere")]  // no number
    public void Weak_passwords_are_rejected(string password)
    {
        var m = ValidRegistration(); m.Password = password; m.ConfirmPassword = password;
        Assert.True(TestHelpers.Validate(m).Count > 0);
    }

    [Theory]
    [InlineData("071221625")]     // 9 digits
    [InlineData("07122162555")]   // 11 digits
    [InlineData("071 221 6255")]  // spaces
    [InlineData("0712A16255")]    // letters
    [InlineData("")]
    public void Bad_phone_numbers_are_rejected(string phone)
    {
        var m = ValidRegistration(); m.ContactNumber = phone;
        Assert.True(TestHelpers.Validate(m).Count > 0);
    }

    [Fact]
    public void Mismatched_passwords_and_bad_usernames_are_rejected()
    {
        var m = ValidRegistration(); m.ConfirmPassword = "Different#123";
        Assert.True(TestHelpers.Validate(m).Count > 0);
        var n = ValidRegistration(); n.Username = "no spaces allowed";
        Assert.True(TestHelpers.Validate(n).Count > 0);
        var o = ValidRegistration(); o.Email = "not-an-email";
        Assert.True(TestHelpers.Validate(o).Count > 0);
    }

    private static PlaceOrderViewModel ValidOrder() => new()
    {
        Items = { }, ExpectedCompletionDate = DateOnly.FromDateTime(Clock.Now.Date.AddDays(1))
    };

    [Fact]
    public void An_order_needs_a_future_date_and_a_valid_item()
    {
        var m = ValidOrder();
        m.Items = new() { new OrderItemInput { ItemType = "Shirt", Quantity = 3, ServiceId = 1 } };
        Assert.Equal(0, TestHelpers.Validate(m).Count);

        m.ExpectedCompletionDate = DateOnly.FromDateTime(Clock.Now.Date.AddDays(-2));
        Assert.True(TestHelpers.Validate(m).Count > 0);
    }

    [Theory]
    [InlineData(0)]
    [InlineData(101)]
    [InlineData(-5)]
    public void Item_quantities_must_be_between_1_and_100(int quantity)
    {
        var item = new OrderItemInput { ItemType = "Shirt", Quantity = quantity, ServiceId = 1 };
        Assert.True(TestHelpers.Validate(item).Count > 0);
    }

    [Fact]
    public void An_item_must_have_a_name_and_a_service()
    {
        Assert.True(TestHelpers.Validate(new OrderItemInput { ItemType = "", Quantity = 1, ServiceId = 1 }).Count > 0);
        Assert.True(TestHelpers.Validate(new OrderItemInput { ItemType = "Shirt", Quantity = 1, ServiceId = 0 }).Count > 0);
    }

    [Fact]
    public void Collection_or_delivery_needs_an_address()
    {
        var m = ValidOrder();
        m.Items = new() { new OrderItemInput { ItemType = "Shirt", Quantity = 1, ServiceId = 1 } };
        m.RequestCollection = true;
        Assert.True(TestHelpers.Validate(m).Count > 0);
        m.AddressLine1 = "1 Test Street"; m.Suburb = "Makhaza";
        Assert.Equal(0, TestHelpers.Validate(m).Count);
    }

    [Fact]
    public void An_order_with_no_items_is_rejected()
    {
        var m = ValidOrder(); m.Items = new();
        Assert.True(TestHelpers.Validate(m).Count > 0);
    }

    [Fact]
    public void Scheduling_checks_the_type_the_address_and_the_date()
    {
        var ok = new ScheduleViewModel { OrderId = 1, TransactionType = "Delivery", AddressId = 4, ScheduledDatetime = Clock.Now.AddHours(3) };
        Assert.Equal(0, TestHelpers.Validate(ok).Count);

        Assert.True(TestHelpers.Validate(new ScheduleViewModel { OrderId = 1, TransactionType = "Pickup", AddressId = 4, ScheduledDatetime = Clock.Now.AddHours(3) }).Count > 0);
        Assert.True(TestHelpers.Validate(new ScheduleViewModel { OrderId = 1, TransactionType = "Delivery", AddressId = 0, ScheduledDatetime = Clock.Now.AddHours(3) }).Count > 0);
        Assert.True(TestHelpers.Validate(new ScheduleViewModel { OrderId = 1, TransactionType = "Delivery", AddressId = 4, ScheduledDatetime = Clock.Now.AddYears(3) }).Count > 0);
    }

    [Fact]
    public void A_new_walk_in_customer_needs_a_valid_phone_number()
    {
        Assert.Equal(0, TestHelpers.Validate(new NewCustomerViewModel { FirstName = "A", LastName = "B", ContactNumber = "0711112222" }).Count);
        Assert.True(TestHelpers.Validate(new NewCustomerViewModel { FirstName = "A", LastName = "B", ContactNumber = "123" }).Count > 0);
    }

    [Fact]
    public void Changing_a_password_needs_a_strong_matching_new_one()
    {
        Assert.Equal(0, TestHelpers.Validate(new ChangePasswordViewModel { CurrentPassword = "x", NewPassword = "Better#456", ConfirmPassword = "Better#456" }).Count);
        Assert.True(TestHelpers.Validate(new ChangePasswordViewModel { CurrentPassword = "x", NewPassword = "weak", ConfirmPassword = "weak" }).Count > 0);
    }
}
