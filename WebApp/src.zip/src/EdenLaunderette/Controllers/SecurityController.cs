using System.Security.Claims;
using EdenLaunderette.Data;
using EdenLaunderette.Models;
using EdenLaunderette.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;

namespace EdenLaunderette.Controllers;

// Lets a logged-in person turn two-factor login on or off. Staff accounts must have it on.
[Authorize]
public class SecurityController : Controller
{
    private readonly AppDbContext _db;
    private readonly TwoFactorService _twoFactor;
    private readonly AccountService _accounts;
    private readonly ILogger<SecurityController> _log;
    public SecurityController(AppDbContext db, TwoFactorService twoFactor, AccountService accounts, ILogger<SecurityController> log)
    { _db = db; _twoFactor = twoFactor; _accounts = accounts; _log = log; }

    private int AccountId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    [HttpGet]
    public async Task<IActionResult> Index()
    {
        var acc = await _db.UserAccounts.AsNoTracking().FirstAsync(a => a.AccountId == AccountId);
        ViewBag.Enabled = acc.TwoFactorEnabled;
        ViewBag.IsEmployee = AppRoles.IsEmployee(User);
        return View();
    }

    [HttpGet]
    public async Task<IActionResult> Setup()
    {
        var acc = await _db.UserAccounts.AsNoTracking().FirstAsync(a => a.AccountId == AccountId);
        if (acc.TwoFactorEnabled) return RedirectToAction(nameof(Index));
        ViewBag.Configured = _twoFactor.IsConfigured;
        if (!_twoFactor.IsConfigured) return View(new SecuritySetupViewModel());

        var secret = _twoFactor.NewSecret();
        ShowSecret(acc.Username, secret);
        return View(new SecuritySetupViewModel { ProtectedSecret = _twoFactor.Encrypt(secret) });
    }

    [HttpPost, EnableRateLimiting("sensitive")]
    public async Task<IActionResult> Setup(SecuritySetupViewModel m)
    {
        ViewBag.Configured = _twoFactor.IsConfigured;
        if (!_twoFactor.IsConfigured) return View(m);

        var acc = await _db.UserAccounts.FirstAsync(a => a.AccountId == AccountId);
        string secret;
        try { secret = _twoFactor.Decrypt(m.ProtectedSecret); }
        catch { TempData["Error"] = "That setup session expired. Please start again."; return RedirectToAction(nameof(Setup)); }

        if (!ModelState.IsValid || !_twoFactor.VerifyCode(secret, m.Code))
        {
            if (ModelState.IsValid) ModelState.AddModelError(nameof(m.Code), "That code isn't right. Check the code in your app and try again.");
            ShowSecret(acc.Username, secret);
            return View(m);
        }

        try
        {
            acc.TwoFactorSecret = m.ProtectedSecret; // already encrypted
            acc.TwoFactorEnabled = true;
            await _db.SaveChangesAsync();
            await RefreshSignInAsync(twoFactor: true);
            TempData["Success"] = "Two-factor login is on. You'll need a code from your app each time you log in.";
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Enabling two-factor failed for account {AccountId}", AccountId);
            TempData["Error"] = "We couldn't turn two-factor on. Please try again.";
        }
        return RedirectToAction(nameof(Index));
    }

    [HttpPost, EnableRateLimiting("sensitive")]
    public async Task<IActionResult> Disable(string? code)
    {
        if (AppRoles.IsEmployee(User))
        {
            TempData["Error"] = "Staff accounts must keep two-factor login on. Ask an administrator if you need it reset.";
            return RedirectToAction(nameof(Index));
        }
        try
        {
            var acc = await _db.UserAccounts.FirstAsync(a => a.AccountId == AccountId);
            if (!acc.TwoFactorEnabled || string.IsNullOrEmpty(acc.TwoFactorSecret)) return RedirectToAction(nameof(Index));
            if (!_twoFactor.VerifyCode(_twoFactor.Decrypt(acc.TwoFactorSecret), code))
            {
                TempData["Error"] = "That code isn't right, so two-factor login is still on.";
                return RedirectToAction(nameof(Index));
            }
            acc.TwoFactorEnabled = false;
            acc.TwoFactorSecret = null;
            await _db.SaveChangesAsync();
            await RefreshSignInAsync(twoFactor: false);
            TempData["Success"] = "Two-factor login is now off.";
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Disabling two-factor failed for account {AccountId}", AccountId);
            TempData["Error"] = "We couldn't turn two-factor off. Please try again.";
        }
        return RedirectToAction(nameof(Index));
    }

    [HttpGet]
    public IActionResult ChangePassword() => View(new ChangePasswordViewModel());

    [HttpPost, EnableRateLimiting("sensitive")]
    public async Task<IActionResult> ChangePassword(ChangePasswordViewModel m)
    {
        if (!ModelState.IsValid) return View(m);
        try
        {
            var acc = await _db.UserAccounts.FirstAsync(a => a.AccountId == AccountId);
            if (!_accounts.VerifyPassword(acc, m.CurrentPassword))
            {
                ModelState.AddModelError(nameof(m.CurrentPassword), "That isn't your current password.");
                return View(m);
            }
            if (m.NewPassword == m.CurrentPassword)
            {
                ModelState.AddModelError(nameof(m.NewPassword), "Choose a password you haven't used just now.");
                return View(m);
            }
            _accounts.SetPassword(acc, m.NewPassword);
            await _db.SaveChangesAsync();
            TempData["Success"] = "Your password has been changed.";
            return RedirectToAction(nameof(Index));
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Changing password failed for account {AccountId}", AccountId);
            ModelState.AddModelError("", "We couldn't change your password. Please try again.");
            return View(m);
        }
    }

    private void ShowSecret(string username, string secret)
    {
        ViewBag.Secret = secret;
        ViewBag.Uri = _twoFactor.BuildUri("Eden Launderette", username, secret);
    }

    // The login cookie carries a "2fa" flag, so refresh it after the setting changes.
    private async Task RefreshSignInAsync(bool twoFactor)
    {
        var claims = User.Claims.Where(c => c.Type != "2fa").ToList();
        claims.Add(new Claim("2fa", twoFactor ? "true" : "false"));
        var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
        await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(identity));
    }
}
