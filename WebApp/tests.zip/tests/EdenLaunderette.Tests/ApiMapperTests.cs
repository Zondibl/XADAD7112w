using EdenLaunderette.Models;
using EdenLaunderette.Services;
using Xunit;

namespace EdenLaunderette.Tests;

public class ApiMapperTests
{
    [Fact]
    public void Detail_adds_up_what_has_been_paid_and_what_is_owing()
    {
        var order = new Order
        {
            OrderNumber = "EDN-000130", OrderStatus = OrderStatuses.Processing, EstimatedTotal = 200m,
            ExpectedCompletionDate = new DateOnly(2026, 10, 20)
        };
        order.Payments.Add(new Payment { ReceiptNumber = "REC-000001", Amount = 50m, PaymentMethod = "Cash", PaymentStatus = "Paid" });
        order.Payments.Add(new Payment { ReceiptNumber = "REC-000002", Amount = 999m, PaymentMethod = "Card", PaymentStatus = "Refunded" });

        var detail = ApiMapper.Detail(order);
        Assert.Equal(50m, detail.Paid);
        Assert.Equal(150m, detail.Outstanding);
        Assert.Equal("EDN-000130", detail.Summary.OrderNumber);
    }

    [Fact]
    public void The_final_total_wins_over_the_estimate()
    {
        var order = new Order { OrderNumber = "EDN-000131", EstimatedTotal = 200m, FinalTotal = 180m };
        order.Payments.Add(new Payment { Amount = 180m, PaymentStatus = "Paid", PaymentMethod = "Cash", ReceiptNumber = "REC-000003" });
        Assert.Equal(0m, ApiMapper.Detail(order).Outstanding);
    }
}
