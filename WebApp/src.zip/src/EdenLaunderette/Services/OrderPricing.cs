namespace EdenLaunderette.Services;

// All money maths lives here, so it can be tested and reused.
public static class OrderPricing
{
    public static decimal LineTotal(decimal unitPrice, int quantity)
    {
        if (unitPrice < 0) throw new ArgumentOutOfRangeException(nameof(unitPrice), "A price can't be negative.");
        if (quantity < 1) throw new ArgumentOutOfRangeException(nameof(quantity), "The quantity must be at least 1.");
        return decimal.Round(unitPrice * quantity, 2, MidpointRounding.AwayFromZero);
    }

    public static decimal Outstanding(decimal due, IEnumerable<decimal> paid) => Math.Max(0, due - paid.Sum());
}
