using System.Security.Claims;
using EdenLaunderette.Data;
using EdenLaunderette.Models;
using EdenLaunderette.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EdenLaunderette.Controllers;

// A delivery driver sees only the collections and deliveries assigned to them.
[Authorize(Roles = AppRoles.Driver)]
public class DriverController : Controller
{
    private static readonly string[] AllowedStatuses = { "In Progress", "Completed", "Failed" };
    private readonly AppDbContext _db;
    private readonly ILogger<DriverController> _log;
    public DriverController(AppDbContext db, ILogger<DriverController> log) { _db = db; _log = log; }

    private int EmployeeId => int.Parse(User.FindFirstValue("EmployeeId")!);

    [HttpGet]
    public async Task<IActionResult> Index()
    {
        var jobs = await _db.CollectionDeliveries.AsNoTracking()
            .Include(j => j.Address).Include(j => j.Order).ThenInclude(o => o.Customer)
            .Where(j => j.EmployeeId == EmployeeId && (j.Status == "Assigned" || j.Status == "In Progress"))
            .OrderBy(j => j.ScheduledDatetime).ToListAsync();
        return View(jobs);
    }

    [HttpPost]
    public async Task<IActionResult> UpdateJob(int id, string status, string? proof, string? notes)
    {
        if (!AllowedStatuses.Contains(status))
        {
            TempData["Error"] = "Choose a valid status.";
            return RedirectToAction(nameof(Index));
        }
        try
        {
            // Only the driver the job is assigned to can change it.
            var job = await _db.CollectionDeliveries.Include(j => j.Order)
                .FirstOrDefaultAsync(j => j.CollectionDeliveryId == id && j.EmployeeId == EmployeeId);
            if (job == null) return NotFound();

            if (status == "Completed" && job.TransactionType == "Delivery" && string.IsNullOrWhiteSpace(proof))
            {
                TempData["Error"] = "Record proof of delivery first, for example who received the laundry.";
                return RedirectToAction(nameof(Index));
            }

            var changed = job.Status != status;
            job.Status = status;
            if (!string.IsNullOrWhiteSpace(proof)) job.ProofOfDelivery = proof.Trim();
            if (!string.IsNullOrWhiteSpace(notes)) job.Notes = notes.Trim();
            if (status == "Completed" || status == "Failed") job.ActualDatetime = Clock.Now;

            var note = OrderService.JobUpdate(job, job.Order.OrderNumber, job.Order.CustomerId, changed, timeChanged: false);
            if (note != null) _db.Notifications.Add(note);
            await _db.SaveChangesAsync();
            TempData["Success"] = $"{job.TransactionType} marked {status}.";
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Driver update failed for job {JobId}", id);
            TempData["Error"] = "The change wasn't saved. Please try again.";
        }
        return RedirectToAction(nameof(Index));
    }
}
