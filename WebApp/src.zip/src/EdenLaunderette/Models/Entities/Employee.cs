namespace EdenLaunderette.Models;

public class Employee
{
    public int EmployeeId { get; set; }
    public string EmployeeNumber { get; set; } = "";
    public string FirstName { get; set; } = "";
    public string LastName { get; set; } = "";
    public string? ContactNumber { get; set; }
    public string? Email { get; set; }
    public string EmployeeRole { get; set; } = "Laundry Staff";
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; } = Clock.Now;
}
