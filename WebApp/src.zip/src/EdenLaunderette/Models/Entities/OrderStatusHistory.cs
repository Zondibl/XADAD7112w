namespace EdenLaunderette.Models;

public class OrderStatusHistory
{
    [System.ComponentModel.DataAnnotations.Key]
    public int StatusHistoryId { get; set; }
    public int OrderId { get; set; }
    public string Status { get; set; } = "";
    public int ChangedByEmployeeId { get; set; }
    public DateTime StatusDate { get; set; } = Clock.Now;
    public string? Notes { get; set; }
}
