using System.Security.Cryptography;
using System.Text;
using Microsoft.AspNetCore.DataProtection;

namespace EdenLaunderette.Services;

// Two-factor login with an authenticator app (Google/Microsoft Authenticator): 6-digit codes that change every 30 seconds (RFC 6238).
public class TwoFactorService
{
    private readonly byte[] _key;
    private readonly ITimeLimitedDataProtector _loginTokens;

    public TwoFactorService(IConfiguration config, IWebHostEnvironment env, IDataProtectionProvider dataProtection, ILogger<TwoFactorService> log)
    {
        var phrase = config["TwoFactor:Key"];
        if (string.IsNullOrWhiteSpace(phrase) && env.IsDevelopment())
        {
            phrase = "development-only-key-set-TwoFactor:Key-in-user-secrets";
            log.LogWarning("TwoFactor:Key is not set. Using a development-only key. Set it with: dotnet user-secrets set \"TwoFactor:Key\" \"<long random phrase>\"");
        }
        _key = string.IsNullOrWhiteSpace(phrase) ? Array.Empty<byte>() : SHA256.HashData(Encoding.UTF8.GetBytes(phrase));
        _loginTokens = dataProtection.CreateProtector("EdenLaunderette.TwoFactor.LoginToken").ToTimeLimitedDataProtector();
    }

    public bool IsConfigured => _key.Length == 32;

    public string NewSecret() => Base32Encode(RandomNumberGenerator.GetBytes(20));

    // The secret is encrypted before it goes into the database, so a leaked database doesn't leak the codes.
    public string Encrypt(string plain)
    {
        var nonce = RandomNumberGenerator.GetBytes(12);
        var data = Encoding.UTF8.GetBytes(plain);
        var cipher = new byte[data.Length];
        var tag = new byte[16];
        using var aes = new AesGcm(_key, 16);
        aes.Encrypt(nonce, data, cipher, tag);
        return Convert.ToBase64String(nonce.Concat(tag).Concat(cipher).ToArray());
    }

    public string Decrypt(string stored)
    {
        var all = Convert.FromBase64String(stored);
        var nonce = all[..12];
        var tag = all[12..28];
        var cipher = all[28..];
        var plain = new byte[cipher.Length];
        using var aes = new AesGcm(_key, 16);
        aes.Decrypt(nonce, cipher, tag, plain);
        return Encoding.UTF8.GetString(plain);
    }

    public bool VerifyCode(string base32Secret, string? code, DateTimeOffset? now = null)
    {
        var digits = new string((code ?? "").Where(char.IsDigit).ToArray());
        if (digits.Length != 6) return false;
        var key = Base32Decode(base32Secret);
        var step = (now ?? DateTimeOffset.UtcNow).ToUnixTimeSeconds() / 30;
        var ok = false;
        for (var drift = -1; drift <= 1; drift++) 
        {
            var expected = Encoding.ASCII.GetBytes(Code(key, step + drift, 6));
            ok |= CryptographicOperations.FixedTimeEquals(expected, Encoding.ASCII.GetBytes(digits));
        }
        return ok;
    }

    public string BuildUri(string issuer, string account, string secret)
        => $"otpauth://totp/{Uri.EscapeDataString(issuer)}:{Uri.EscapeDataString(account)}?secret={secret}&issuer={Uri.EscapeDataString(issuer)}&digits=6&period=30";

    // Proves the password step was passed, for 5 minutes, without logging the person in yet.
    public string CreateLoginToken(int accountId, string? returnUrl)
        => _loginTokens.Protect($"{accountId}|{returnUrl}", TimeSpan.FromMinutes(5));

    public bool TryReadLoginToken(string token, out int accountId, out string? returnUrl)
    {
        accountId = 0; returnUrl = null;
        try
        {
            var parts = _loginTokens.Unprotect(token).Split('|', 2);
            if (!int.TryParse(parts[0], out accountId)) return false;
            returnUrl = parts.Length > 1 && parts[1].Length > 0 ? parts[1] : null;
            return true;
        }
        catch (CryptographicException) { return false; }
    }

    public static string Code(byte[] key, long counter, int digits)
    {
        var msg = BitConverter.GetBytes(counter);
        if (BitConverter.IsLittleEndian) Array.Reverse(msg);
        var hash = HMACSHA1.HashData(key, msg);
        var offset = hash[^1] & 0x0F;
        var binary = ((hash[offset] & 0x7F) << 24) | (hash[offset + 1] << 16) | (hash[offset + 2] << 8) | hash[offset + 3];
        var mod = 1; for (var i = 0; i < digits; i++) mod *= 10;
        return (binary % mod).ToString().PadLeft(digits, '0');
    }

    private const string Alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";

    public static string Base32Encode(byte[] data)
    {
        var sb = new StringBuilder();
        int buffer = 0, bits = 0;
        foreach (var b in data)
        {
            buffer = (buffer << 8) | b; bits += 8;
            while (bits >= 5) { sb.Append(Alphabet[(buffer >> (bits - 5)) & 31]); bits -= 5; }
        }
        if (bits > 0) sb.Append(Alphabet[(buffer << (5 - bits)) & 31]);
        return sb.ToString();
    }

    public static byte[] Base32Decode(string text)
    {
        var bytes = new List<byte>();
        int buffer = 0, bits = 0;
        foreach (var c in text.TrimEnd('=').ToUpperInvariant())
        {
            var v = Alphabet.IndexOf(c);
            if (v < 0) continue;
            buffer = (buffer << 5) | v; bits += 5;
            if (bits >= 8) { bytes.Add((byte)((buffer >> (bits - 8)) & 0xFF)); bits -= 8; }
        }
        return bytes.ToArray();
    }
}
