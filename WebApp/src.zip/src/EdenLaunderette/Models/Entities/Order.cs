namespace EdenLaunderette.Models;

public class Order
{
    public int OrderId { get; set; }
    public string OrderNumber { get; set; } = "";
    public int CustomerId { get; set; }
    public int ReceivedByEmployeeId { get; set; }
    public DateTime ReceivedAt { get; set; } = Clock.Now;
    public DateOnly ExpectedCompletionDate { get; set; }
    public string OrderStatus { get; set; } = OrderStatuses.Received;
    public decimal EstimatedTotal { get; set; }
    public decimal? FinalTotal { get; set; }
    public string? SpecialInstructions { get; set; }
    public DateTime? CompletedAt { get; set; }
    public DateTime CreatedAt { get; set; } = Clock.Now;
    public DateTime UpdatedAt { get; set; } = Clock.Now;

    public Customer Customer { get; set; } = null!;
    public ICollection<OrderItem> Items { get; set; } = new List<OrderItem>();
    public ICollection<OrderStatusHistory> StatusHistory { get; set; } = new List<OrderStatusHistory>();
    public ICollection<Payment> Payments { get; set; } = new List<Payment>();
    public ICollection<CollectionDelivery> CollectionDeliveries { get; set; } = new List<CollectionDelivery>();
}
