namespace EdenLaunderette.Models;

public class OrderItemService
{
    public int OrderItemServiceId { get; set; }
    public int OrderItemId { get; set; }
    public int ServiceId { get; set; }
    public int Quantity { get; set; }
    public decimal UnitPrice { get; set; }   
    public decimal LineTotal { get; set; }

    public Service Service { get; set; } = null!;
}
