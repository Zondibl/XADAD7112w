using System.ComponentModel.DataAnnotations;

namespace EdenLaunderette.Models;

public class NewCustomerViewModel
{
    [Required(ErrorMessage = "Enter the customer's first name."), StringLength(60)]
    [Display(Name = "First name")]
    public string FirstName { get; set; } = "";

    [Required(ErrorMessage = "Enter the customer's last name."), StringLength(60)]
    [Display(Name = "Last name")]
    public string LastName { get; set; } = "";

    [Required(ErrorMessage = "Enter a contact number.")]
    [RegularExpression(@"^0\d{9}$", ErrorMessage = "Enter a 10-digit South African number with no spaces, e.g. 0712216255.")]
    [Display(Name = "Contact number")]
    public string ContactNumber { get; set; } = "";

    [EmailAddress(ErrorMessage = "Enter a valid email address."), StringLength(120)]
    public string? Email { get; set; }
}

public class ScheduleViewModel : IValidatableObject
{
    public int OrderId { get; set; }

    [Required(ErrorMessage = "Choose collection or delivery.")]
    [Display(Name = "Type")]
    public string TransactionType { get; set; } = "";

    [Display(Name = "Address")]
    public int AddressId { get; set; } 

    [StringLength(120)] public string? AddressLine1 { get; set; }
    [StringLength(80)] public string? Suburb { get; set; }
    [StringLength(80)] public string City { get; set; } = "Cape Town";
    [StringLength(80)] public string Province { get; set; } = "Western Cape";
    [StringLength(10)] public string? PostalCode { get; set; }

    [Required(ErrorMessage = "Choose a date and time.")]
    [Display(Name = "Date and time")]
    public DateTime ScheduledDatetime { get; set; }

    [Display(Name = "Driver")]
    public int? EmployeeId { get; set; }

    [StringLength(500, ErrorMessage = "Keep notes under 500 characters.")]
    public string? Notes { get; set; }

    public IEnumerable<ValidationResult> Validate(ValidationContext ctx)
    {
        if (TransactionType != "Collection" && TransactionType != "Delivery")
            yield return new ValidationResult("Choose collection or delivery.", new[] { nameof(TransactionType) });
        if (AddressId == 0 && (string.IsNullOrWhiteSpace(AddressLine1) || string.IsNullOrWhiteSpace(Suburb)))
            yield return new ValidationResult("Choose a saved address, or enter the street address and suburb.", new[] { nameof(AddressLine1) });
        var now = Clock.Now;
        if (ScheduledDatetime < now.AddDays(-1) || ScheduledDatetime > now.AddDays(365))
            yield return new ValidationResult("Choose a date and time within the next year.", new[] { nameof(ScheduledDatetime) });
    }
}
