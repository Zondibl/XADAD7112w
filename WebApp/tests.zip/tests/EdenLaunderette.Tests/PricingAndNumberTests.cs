using EdenLaunderette.Data;
using EdenLaunderette.Models;
using EdenLaunderette.Services;
using Xunit;

namespace EdenLaunderette.Tests;

public class PricingAndNumberTests
{
    [Theory]
    [InlineData(15.00, 8, 120.00)]
    [InlineData(10.50, 3, 31.50)]
    [InlineData(0.00, 5, 0.00)]
    public void Line_total_is_price_times_quantity(double price, int qty, double expected)
        => Assert.Equal((decimal)expected, OrderPricing.LineTotal((decimal)price, qty));

    [Fact]
    public void Line_total_rejects_impossible_input()
    {
        Assert.Throws<ArgumentOutOfRangeException>(() => OrderPricing.LineTotal(10m, 0));
        Assert.Throws<ArgumentOutOfRangeException>(() => OrderPricing.LineTotal(-1m, 2));
    }

    [Fact]
    public void Outstanding_never_goes_below_zero()
    {
        Assert.Equal(40m, OrderPricing.Outstanding(100m, new[] { 60m }));
        Assert.Equal(0m, OrderPricing.Outstanding(100m, new[] { 60m, 60m }));
        Assert.Equal(100m, OrderPricing.Outstanding(100m, Array.Empty<decimal>()));
    }

    [Theory]
    [InlineData(null, "EDN-", 6, "EDN-000001")]
    [InlineData("EDN-000129", "EDN-", 6, "EDN-000130")]
    [InlineData("CUS-00005", "CUS-", 5, "CUS-00006")]
    [InlineData("REC-000009", "REC-", 6, "REC-000010")]
    [InlineData("TMP-abc", "EDN-", 6, "EDN-000001")]
    public void Next_number_follows_the_test_data_format(string? last, string prefix, int width, string expected)
        => Assert.Equal(expected, NumberGenerator.Next(last, prefix, width));

    [Fact]
    public void Money_is_shown_with_two_decimals_and_a_dot()
    {
        Assert.Equal("R15.00", Fmt.Rand(15m));
        Assert.Equal("R1234.50", Fmt.Rand(1234.5m));
    }

    [Theory]
    [InlineData("Ready for Collection", "status-ready-for-collection")]
    [InlineData("In Progress", "status-in-progress")]
    [InlineData("Received", "status-received")]
    public void Status_text_becomes_a_css_class(string status, string expected)
        => Assert.Equal(expected, Fmt.StatusClass(status));
}
