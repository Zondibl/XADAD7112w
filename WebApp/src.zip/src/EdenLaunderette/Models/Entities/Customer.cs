namespace EdenLaunderette.Models;

public class Customer
{
    public int CustomerId { get; set; }
    public string CustomerNumber { get; set; } = "";
    public string FirstName { get; set; } = "";
    public string LastName { get; set; } = "";
    public string ContactNumber { get; set; } = "";
    public string? Email { get; set; }
    public DateOnly DateRegistered { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; } = Clock.Now;
    public DateTime UpdatedAt { get; set; } = Clock.Now;

    public UserAccount? Account { get; set; }
    public ICollection<CustomerAddress> Addresses { get; set; } = new List<CustomerAddress>();
    public ICollection<Order> Orders { get; set; } = new List<Order>();
}
