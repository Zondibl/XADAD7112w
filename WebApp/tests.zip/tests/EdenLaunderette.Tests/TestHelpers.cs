using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Logging.Abstractions;
using EdenLaunderette.Services;

namespace EdenLaunderette.Tests;

internal sealed class FakeEnv : IWebHostEnvironment
{
    public string WebRootPath { get; set; } = "";
    public IFileProvider WebRootFileProvider { get; set; } = null!;
    public string ApplicationName { get; set; } = "tests";
    public IFileProvider ContentRootFileProvider { get; set; } = null!;
    public string ContentRootPath { get; set; } = "";
    public string EnvironmentName { get; set; } = "Production";
}

internal static class TestHelpers
{
    public static IConfiguration Config(params (string Key, string Value)[] values)
        => new ConfigurationBuilder().AddInMemoryCollection(values.ToDictionary(v => v.Key, v => (string?)v.Value)).Build();

    public static TwoFactorService TwoFactor(string key = "unit-test-phrase")
        => new(Config(("TwoFactor:Key", key)), new FakeEnv(), DataProtectionProvider.Create("tests"), NullLogger<TwoFactorService>.Instance);

    public static JwtService Jwt(string key = "a-unit-test-key-that-is-at-least-32-characters-long")
        => new(Config(("Jwt:Key", key)), new FakeEnv(), NullLogger<JwtService>.Instance);

    // Runs the same DataAnnotations checks the website runs, and returns the error messages.
    public static List<string> Validate(object model)
    {
        var results = new List<ValidationResult>();
        Validator.TryValidateObject(model, new ValidationContext(model), results, validateAllProperties: true);
        return results.Select(r => r.ErrorMessage ?? "").ToList();
    }

    // Finds the repository root (the folder that contains "database") so tests can read the SQL scripts.
    public static string RepoRoot()
    {
        var dir = new DirectoryInfo(AppContext.BaseDirectory);
        while (dir != null && !Directory.Exists(Path.Combine(dir.FullName, "database"))) dir = dir.Parent;
        return dir?.FullName ?? throw new DirectoryNotFoundException("Couldn't find the repository root (a folder containing 'database').");
    }
}
