using EdenLaunderette.Models;

namespace EdenLaunderette.Services;

public static class PaymentRules
{
    public static decimal PaidTotal(IEnumerable<Payment> payments)
        => payments.Where(p => p.PaymentStatus == "Paid").Sum(p => p.Amount);

    public static Payment? NextPending(IEnumerable<Payment> payments)
        => payments.Where(p => p.PaymentStatus == "Pending").OrderBy(p => p.PaymentId).FirstOrDefault();
}
