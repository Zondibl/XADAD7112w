using EdenLaunderette.Data;
using EdenLaunderette.Models.Api;
using EdenLaunderette.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;

namespace EdenLaunderette.Controllers.Api;

[ApiController, IgnoreAntiforgeryToken, Route("api")]
public class PublicApiController : ControllerBase
{
    private readonly AppDbContext _db;
    public PublicApiController(AppDbContext db) => _db = db;

    [HttpGet("services")]
    public async Task<IActionResult> Services()
    {
        var list = await _db.Services.AsNoTracking().Where(s => s.IsActive).OrderBy(s => s.ServiceName).ToListAsync();
        return Ok(list.Select(s => new ServiceDto(s.ServiceId, s.ServiceName, s.Description, s.PricePerItem)));
    }

    [HttpPost("track"), EnableRateLimiting("sensitive")]
    public async Task<IActionResult> Track(ApiTrackRequest r)
    {
        var number = r.OrderNumber.Trim().ToUpperInvariant();
        var phone = new string(r.ContactNumber.Where(char.IsDigit).ToArray());
        var order = await _db.Orders.AsNoTracking()
            .Include(o => o.Items).ThenInclude(i => i.Services).ThenInclude(s => s.Service)
            .Include(o => o.StatusHistory).Include(o => o.Payments).Include(o => o.CollectionDeliveries)
            .FirstOrDefaultAsync(o => o.OrderNumber == number && o.Customer.ContactNumber == phone);
        // Same answer whether the number or the phone was wrong.
        return order == null
            ? NotFound(new { error = "We couldn't find an order with those details." })
            : Ok(ApiMapper.Detail(order));
    }
}
