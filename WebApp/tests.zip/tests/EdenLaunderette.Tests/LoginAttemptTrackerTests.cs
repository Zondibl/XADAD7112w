using EdenLaunderette.Services;
using Xunit;

namespace EdenLaunderette.Tests;

public class LoginAttemptTrackerTests
{
    [Fact]
    public void Five_wrong_passwords_lock_the_account()
    {
        var now = new DateTime(2026, 10, 15, 9, 0, 0);
        var tracker = new LoginAttemptTracker(() => now);
        for (var i = 0; i < 4; i++) tracker.RecordFailure("john");
        Assert.False(tracker.IsLocked("john", out _));
        tracker.RecordFailure("john");
        Assert.True(tracker.IsLocked("john", out var remaining));
        Assert.True(remaining > TimeSpan.FromMinutes(14));
    }

    [Fact]
    public void The_lock_ends_after_fifteen_minutes()
    {
        var now = new DateTime(2026, 10, 15, 9, 0, 0);
        var tracker = new LoginAttemptTracker(() => now);
        for (var i = 0; i < 5; i++) tracker.RecordFailure("john");
        now = now.AddMinutes(16);
        Assert.False(tracker.IsLocked("john", out _));
    }

    [Fact]
    public void A_correct_login_clears_the_count_and_usernames_ignore_case()
    {
        var tracker = new LoginAttemptTracker();
        for (var i = 0; i < 4; i++) tracker.RecordFailure("John");
        tracker.Reset("john");
        tracker.RecordFailure("JOHN");
        Assert.False(tracker.IsLocked("john", out _));
    }

    [Fact]
    public void Old_failures_expire_and_other_users_are_unaffected()
    {
        var now = new DateTime(2026, 10, 15, 9, 0, 0);
        var tracker = new LoginAttemptTracker(() => now);
        for (var i = 0; i < 4; i++) tracker.RecordFailure("john");
        now = now.AddMinutes(20);
        tracker.RecordFailure("john");
        Assert.False(tracker.IsLocked("john", out _));
        for (var i = 0; i < 5; i++) tracker.RecordFailure("thandi");
        Assert.False(tracker.IsLocked("sarah", out _));
    }
}
