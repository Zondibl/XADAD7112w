using System.Security.Claims;

namespace EdenLaunderette.Models;

// Role names are the values allowed by chk_employee_role in the database.
public static class AppRoles
{
    public const string Customer = "Customer";
    public const string Administrator = "Administrator";
    public const string Driver = "Delivery Driver";
    public const string StaffArea = "Administrator,Manager,Laundry Staff,Cashier";
    public const string EmployeeRoles = "Administrator,Manager,Laundry Staff,Cashier,Delivery Driver";
    public static bool IsStaff(ClaimsPrincipal u) => StaffArea.Split(',').Any(u.IsInRole);
    public static bool IsEmployee(ClaimsPrincipal u) => EmployeeRoles.Split(',').Any(u.IsInRole);
}

// Values allowed by chk_order_status in the database.
public static class OrderStatuses
{
    public const string Received = "Received";
    public const string Processing = "Processing";
    public const string ReadyForCollection = "Ready for Collection";
    public const string ReadyForDelivery = "Ready for Delivery";
    public const string Dispatched = "Dispatched";
    public const string Completed = "Completed";
    public const string Cancelled = "Cancelled";
    public static readonly string[] All =
        { Received, Processing, ReadyForCollection, ReadyForDelivery, Dispatched, Completed, Cancelled };
}

public static class JobStatuses
{
    public static readonly string[] All = { "Scheduled", "Assigned", "In Progress", "Completed", "Failed", "Cancelled" };
}

public static class PaymentMethods
{
    public static readonly string[] All = { "Cash", "Card", "EFT", "Online" };
   
    public static readonly string[] CustomerChoices = { "Cash", "Card", "EFT" };
}
