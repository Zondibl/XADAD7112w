// Behaviour for the order form (add/remove item rows, show the address only when needed).
(function () {
    const list = document.getElementById('itemList');
    const tpl = document.getElementById('itemTemplate');
    if (!list || !tpl) return;

    // Keep Items[0], Items[1]... in order so the server can read every row.
    function reindex() {
        [...list.querySelectorAll('.item-row')].forEach((row, i) => {
            row.querySelectorAll('[name]').forEach(el => el.name = el.name.replace(/Items\[\d+\]/, 'Items[' + i + ']'));
            row.querySelector('.remove-item').hidden = list.children.length === 1;
        });
    }
    document.getElementById('addItem').addEventListener('click', () => { list.appendChild(tpl.content.cloneNode(true)); reindex(); });
    list.addEventListener('click', e => {
        if (e.target.classList.contains('remove-item')) { e.target.closest('.item-row').remove(); reindex(); }
    });
    reindex();

    // Only ask for an address when collection or delivery is chosen.
    const addr = document.getElementById('addressBlock');
    const boxes = [document.getElementById('RequestCollection'), document.getElementById('RequestDelivery')];
    function toggleAddr() { addr.hidden = !boxes.some(b => b.checked); }
    boxes.forEach(b => b.addEventListener('change', toggleAddr));
    toggleAddr();
})();
