using EdenLaunderette.Data;
using EdenLaunderette.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace EdenLaunderette.Services;

public class AccountService
{
    private readonly AppDbContext _db;
    
    private readonly PasswordHasher<UserAccount> _hasher = new();
    public AccountService(AppDbContext db) => _db = db;

    public bool VerifyPassword(UserAccount account, string password)
        => _hasher.VerifyHashedPassword(account, account.PasswordHash, password) != PasswordVerificationResult.Failed;

    public void SetPassword(UserAccount account, string password) => account.PasswordHash = _hasher.HashPassword(account, password);

    public async Task<(UserAccount? Account, string? Error)> RegisterCustomerAsync(RegisterViewModel m)
    {
        var username = m.Username.Trim();
        if (await _db.UserAccounts.AnyAsync(a => a.Username.ToLower() == username.ToLower()))
            return (null, "That username is taken. Try another one.");

        await using var tx = await _db.Database.BeginTransactionAsync();
        var now = Clock.Now;
        var customer = new Customer
        {
            CustomerNumber = await NumberGenerator.NextAsync(_db.Customers.Select(c => c.CustomerNumber), "CUS-", 5),
            FirstName = m.FirstName.Trim(), LastName = m.LastName.Trim(), ContactNumber = m.ContactNumber, Email = m.Email.Trim(),
            DateRegistered = DateOnly.FromDateTime(now), CreatedAt = now, UpdatedAt = now
        };
        _db.Customers.Add(customer);
        await _db.SaveChangesAsync();

        var account = new UserAccount { CustomerId = customer.CustomerId, Username = username, LastLogin = now, Customer = customer };
        SetPassword(account, m.Password);
        _db.UserAccounts.Add(account);
        await _db.SaveChangesAsync();
        await tx.CommitAsync();
        return (account, null);
    }
}
