namespace EdenLaunderette.Models;

public class CustomerAddress
{
    [System.ComponentModel.DataAnnotations.Key]
    public int AddressId { get; set; }
    public int CustomerId { get; set; }
    public string AddressType { get; set; } = "Home"; // Home, Work or Other
    public string AddressLine1 { get; set; } = "";
    public string? AddressLine2 { get; set; }
    public string? Suburb { get; set; }
    public string City { get; set; } = "";
    public string? Province { get; set; }
    public string? PostalCode { get; set; }
    public bool IsDefault { get; set; }
    public DateTime CreatedAt { get; set; } = Clock.Now;
}
