namespace EdenLaunderette.Models;

public class Service
{
    public int ServiceId { get; set; }
    public string ServiceCode { get; set; } = "";
    public string ServiceName { get; set; } = "";
    public string? Description { get; set; }
    public decimal PricePerItem { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; } = Clock.Now;
}
