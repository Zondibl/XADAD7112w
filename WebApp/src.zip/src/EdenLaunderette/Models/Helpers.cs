namespace EdenLaunderette.Models;

public static class Fmt
{
    public static string Rand(decimal d) => "R" + d.ToString("0.00", System.Globalization.CultureInfo.InvariantCulture);
    public static string StatusClass(string status) => "status-" + status.ToLowerInvariant().Replace(' ', '-');
}

public static class Clock
{
    private static readonly TimeZoneInfo Tz = Find();
    private static TimeZoneInfo Find()
    {
        foreach (var id in new[] { "Africa/Johannesburg", "South Africa Standard Time" })
        {
            try { return TimeZoneInfo.FindSystemTimeZoneById(id); } catch { }
        }
        return TimeZoneInfo.Utc;
    }
    public static DateTime Now => TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, Tz);
}
