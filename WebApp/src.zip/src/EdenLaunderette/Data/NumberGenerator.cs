using Microsoft.EntityFrameworkCore;

namespace EdenLaunderette.Data;

// Makes the next number in the same format as the test data, e.g. EDN-000130, CUS-00006, REC-000130.
public static class NumberGenerator
{
    public static string Next(string? last, string prefix, int width)
    {
        var next = 1;
        if (last != null && last.StartsWith(prefix) && int.TryParse(last.AsSpan(prefix.Length), out var parsed)) next = parsed + 1;
        return prefix + next.ToString().PadLeft(width, '0');
    }

    public static async Task<string> NextAsync(IQueryable<string> existing, string prefix, int width)
    {
        var last = await existing.Where(x => x.StartsWith(prefix)).OrderByDescending(x => x).FirstOrDefaultAsync();
        return Next(last, prefix, width);
    }
}
