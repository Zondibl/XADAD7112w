using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace EdenLaunderette.Services;


public class JwtService
{
    private const string Issuer = "EdenLaunderette";
    private readonly byte[] _key;
    public JwtService(IConfiguration config, IWebHostEnvironment env, ILogger<JwtService> log)
    {
        var key = config["Jwt:Key"];
        if (string.IsNullOrWhiteSpace(key) && env.IsDevelopment())
        {
            key = "development-only-jwt-key-set-Jwt:Key-in-user-secrets";
            log.LogWarning("Jwt:Key is not set. Using a development-only key. Set it with: dotnet user-secrets set \"Jwt:Key\" \"<random text, 32+ characters>\"");
        }
        _key = !string.IsNullOrWhiteSpace(key) && key.Length >= 32 ? Encoding.UTF8.GetBytes(key) : Array.Empty<byte>();
    }

    public bool IsConfigured => _key.Length >= 32;

    public string Create(int accountId, int customerId, TimeSpan lifetime, DateTimeOffset? now = null)
    {
        if (!IsConfigured) throw new InvalidOperationException("Jwt:Key is missing or shorter than 32 characters.");
        var issued = now ?? DateTimeOffset.UtcNow;
        var header = B64(Encoding.UTF8.GetBytes("{\"alg\":\"HS256\",\"typ\":\"JWT\"}"));
        var payload = B64(JsonSerializer.SerializeToUtf8Bytes(new Dictionary<string, object>
        {
            ["iss"] = Issuer, ["sub"] = accountId, ["cid"] = customerId,
            ["iat"] = issued.ToUnixTimeSeconds(), ["exp"] = issued.Add(lifetime).ToUnixTimeSeconds()
        }));
        return $"{header}.{payload}.{B64(Sign($"{header}.{payload}"))}";
    }

    public bool TryValidate(string? token, out int accountId, out int customerId, DateTimeOffset? now = null)
    {
        accountId = 0; customerId = 0;
        if (!IsConfigured || string.IsNullOrWhiteSpace(token)) return false;
        var parts = token.Split('.');
        if (parts.Length != 3) return false;
        try
        {
    
            var expected = Sign($"{parts[0]}.{parts[1]}");
            if (!CryptographicOperations.FixedTimeEquals(expected, FromB64(parts[2]))) return false;

            using var doc = JsonDocument.Parse(FromB64(parts[1]));
            var root = doc.RootElement;
            if (root.GetProperty("iss").GetString() != Issuer) return false;
            if (root.GetProperty("exp").GetInt64() <= (now ?? DateTimeOffset.UtcNow).ToUnixTimeSeconds()) return false;
            accountId = root.GetProperty("sub").GetInt32();
            customerId = root.GetProperty("cid").GetInt32();
            return true;
        }
        catch (Exception ex) when (ex is FormatException or JsonException or KeyNotFoundException or InvalidOperationException)
        {
            return false;
        }
    }

    private byte[] Sign(string data) => HMACSHA256.HashData(_key, Encoding.UTF8.GetBytes(data));
    private static string B64(byte[] b) => Convert.ToBase64String(b).TrimEnd('=').Replace('+', '-').Replace('/', '_');
    private static byte[] FromB64(string s)
    {
        s = s.Replace('-', '+').Replace('_', '/');
        return Convert.FromBase64String(s.PadRight(s.Length + (4 - s.Length % 4) % 4, '='));
    }
}
