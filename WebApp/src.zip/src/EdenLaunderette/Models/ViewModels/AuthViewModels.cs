using System.ComponentModel.DataAnnotations;

namespace EdenLaunderette.Models;

public class RegisterViewModel
{
    [Required(ErrorMessage = "Enter your first name."), StringLength(60)]
    [Display(Name = "First name")]
    public string FirstName { get; set; } = "";

    [Required(ErrorMessage = "Enter your last name."), StringLength(60)]
    [Display(Name = "Last name")]
    public string LastName { get; set; } = "";

    [Required(ErrorMessage = "Enter your contact number.")]
    [RegularExpression(@"^0\d{9}$", ErrorMessage = "Enter a 10-digit South African number with no spaces, e.g. 0712216255.")]
    [Display(Name = "Contact number")]
    public string ContactNumber { get; set; } = "";

    [Required(ErrorMessage = "Enter your email address."), EmailAddress(ErrorMessage = "Enter a valid email address."), StringLength(120)]
    public string Email { get; set; } = "";

    [Required(ErrorMessage = "Choose a username.")]
    [RegularExpression(@"^[A-Za-z0-9._]{3,30}$", ErrorMessage = "Use 3-30 letters, numbers, dots or underscores.")]
    public string Username { get; set; } = "";

    [Required(ErrorMessage = "Choose a password."), DataType(DataType.Password)]
    [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,100}$",
        ErrorMessage = "Use at least 8 characters, with an uppercase letter, a lowercase letter and a number.")]
    public string Password { get; set; } = "";

    [Required(ErrorMessage = "Repeat your password."), DataType(DataType.Password)]
    [Compare(nameof(Password), ErrorMessage = "The passwords don't match.")]
    [Display(Name = "Confirm password")]
    public string ConfirmPassword { get; set; } = "";
}

public class LoginViewModel
{
    [Required(ErrorMessage = "Enter your username.")]
    public string Username { get; set; } = "";

    [Required(ErrorMessage = "Enter your password."), DataType(DataType.Password)]
    public string Password { get; set; } = "";

    public string? ReturnUrl { get; set; }
}

public class TwoFactorViewModel
{
    [Required] public string Token { get; set; } = "";

    [Required(ErrorMessage = "Enter the 6-digit code from your authenticator app.")]
    [Display(Name = "6-digit code")]
    public string Code { get; set; } = "";
}

public class SecuritySetupViewModel
{
    [Required] public string ProtectedSecret { get; set; } = "";

    [Required(ErrorMessage = "Enter the 6-digit code shown in your authenticator app.")]
    [Display(Name = "6-digit code")]
    public string Code { get; set; } = "";
}

public class ChangePasswordViewModel
{
    [Required(ErrorMessage = "Enter your current password."), DataType(DataType.Password)]
    [Display(Name = "Current password")]
    public string CurrentPassword { get; set; } = "";

    [Required(ErrorMessage = "Choose a new password."), DataType(DataType.Password)]
    [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,100}$",
        ErrorMessage = "Use at least 8 characters, with an uppercase letter, a lowercase letter and a number.")]
    [Display(Name = "New password")]
    public string NewPassword { get; set; } = "";

    [Required(ErrorMessage = "Repeat the new password."), DataType(DataType.Password)]
    [Compare(nameof(NewPassword), ErrorMessage = "The passwords don't match.")]
    [Display(Name = "Confirm new password")]
    public string ConfirmPassword { get; set; } = "";
}

public class ProfileViewModel
{
    [Required(ErrorMessage = "Enter your first name."), StringLength(60)]
    [Display(Name = "First name")]
    public string FirstName { get; set; } = "";

    [Required(ErrorMessage = "Enter your last name."), StringLength(60)]
    [Display(Name = "Last name")]
    public string LastName { get; set; } = "";

    [Required(ErrorMessage = "Enter your contact number.")]
    [RegularExpression(@"^0\d{9}$", ErrorMessage = "Enter a 10-digit South African number with no spaces, e.g. 0712216255.")]
    [Display(Name = "Contact number")]
    public string ContactNumber { get; set; } = "";

    [Required(ErrorMessage = "Enter your email address."), EmailAddress(ErrorMessage = "Enter a valid email address."), StringLength(120)]
    public string Email { get; set; } = "";
}
