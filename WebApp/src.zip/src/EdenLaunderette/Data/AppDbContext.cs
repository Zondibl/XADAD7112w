using EdenLaunderette.Models;
using Microsoft.EntityFrameworkCore;

namespace EdenLaunderette.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<Employee> Employees => Set<Employee>();
    public DbSet<Customer> Customers => Set<Customer>();
    public DbSet<CustomerAddress> CustomerAddresses => Set<CustomerAddress>();
    public DbSet<UserAccount> UserAccounts => Set<UserAccount>();
    public DbSet<Service> Services => Set<Service>();
    public DbSet<Order> Orders => Set<Order>();
    public DbSet<OrderItem> OrderItems => Set<OrderItem>();
    public DbSet<OrderItemService> OrderItemServices => Set<OrderItemService>();
    public DbSet<OrderStatusHistory> OrderStatusHistory => Set<OrderStatusHistory>();
    public DbSet<Payment> Payments => Set<Payment>();
    public DbSet<CollectionDelivery> CollectionDeliveries => Set<CollectionDelivery>();
    public DbSet<Notification> Notifications => Set<Notification>();

    protected override void ConfigureConventions(ModelConfigurationBuilder cb)
        => cb.Properties<decimal>().HavePrecision(10, 2);

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<CollectionDelivery>().ToTable("collection_delivery"); 

        b.Entity<Employee>().HasIndex(e => e.EmployeeNumber).IsUnique();
        b.Entity<Customer>().HasIndex(c => c.CustomerNumber).IsUnique();
        b.Entity<UserAccount>().HasIndex(a => a.Username).IsUnique();
        b.Entity<Order>().HasIndex(o => o.OrderNumber).IsUnique();
        b.Entity<Payment>().HasIndex(p => p.ReceiptNumber).IsUnique();
        b.Entity<Service>().HasIndex(s => s.ServiceCode).IsUnique();
    }
}
